import cv2
import pytesseract
import re

pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

def extract_check_details(image_path):
    img = cv2.imread(image_path)
    h, w = img.shape[:2]

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

    config = r'--oem 3 --psm 6'

    # Date region (top-right ~20% width, 15% height)
    date_roi = gray[0:int(h*0.15), int(w*0.7):w]
    date_text = pytesseract.image_to_string(date_roi, config=config)

    # Amount in words (middle line)
    amount_words_roi = gray[int(h*0.35):int(h*0.5), 0:int(w*0.8)]
    amount_words_text = pytesseract.image_to_string(amount_words_roi, config=config)

    # Amount in digits (box right side)
    amount_digits_roi = gray[int(h*0.35):int(h*0.5), int(w*0.75):w]
    amount_digits_text = pytesseract.image_to_string(amount_digits_roi, config=config)

    # MICR/account (bottom strip)
    micr_roi = gray[int(h*0.85):h, :]
    micr_text = pytesseract.image_to_string(micr_roi, config='--oem 3 --psm 7')

    # Regex cleanup
    date_pattern = r'(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|[A-Za-z]+\s+\d{1,2},?\s+\d{4})'
    amount_words_pattern = r'(Rupees\s+[A-Za-z\s]+Only)'
    amount_digits_pattern = r'(\₹?\$?\s?\d+[,.]?\d*)'
    account_pattern = r'(\d{9,18})'  # typical account length

    date = re.search(date_pattern, date_text)
    amount_words = re.search(amount_words_pattern, amount_words_text)
    amount_digits = re.search(amount_digits_pattern, amount_digits_text)
    account = re.search(account_pattern, micr_text)

    return {
        "date": date.group(0) if date else date_text.strip(),
        "amount_words": amount_words.group(0) if amount_words else amount_words_text.strip(),
        "amount_digits": amount_digits.group(0) if amount_digits else amount_digits_text.strip(),
        "account_number": account.group(0) if account else micr_text.strip()
    }

if __name__ == "__main__":
    details = extract_check_details("checkImg.png")
    print(details)
