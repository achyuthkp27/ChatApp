import os
import cv2
import numpy as np
from insightface.app import FaceAnalysis
from insightface.model_zoo import get_model
from insightface.utils import face_align

# Set model directory
model_root = os.path.expanduser("~/.insightface/models")

# Load face detector (uses det_10g.onnx internally)
detector = FaceAnalysis(name='buffalo_l', root=model_root, providers=['CPUExecutionProvider'])
detector.prepare(ctx_id=0, det_size=(640, 640))

# Load face recognition model manually
recognition_model_path = os.path.join(model_root, "buffalo_l", "w600k_r50.onnx")
recognizer = get_model(recognition_model_path, providers=['CPUExecutionProvider'])
recognizer.prepare(ctx_id=0)


def get_face_embedding(image_path):
    img = cv2.imread(image_path)
    if img is None:
        print(f"Could not read image: {image_path}")
        return None

    faces = detector.get(img)
    if len(faces) == 0:
        print(f"No face detected in {image_path}")
        return None

    return faces[0].normed_embedding

def compare_faces(img1_path, img2_path, threshold=0.6):
    emb1 = get_face_embedding(img1_path)
    emb2 = get_face_embedding(img2_path)

    if emb1 is None or emb2 is None:
        return "Face not detected in one or both images."

    emb1 = emb1 / np.linalg.norm(emb1)
    emb2 = emb2 / np.linalg.norm(emb2)

    similarity = np.dot(emb1, emb2)
    print(f"Similarity score: {similarity:.4f}")

    if similarity > threshold:
        return "Same person ✅"
    else:
        return "Different person ❌"


# Example usage
img1 = "Achu.png"
img2 = "Achu2.png"
result = compare_faces(img1, img2)
print(result)
