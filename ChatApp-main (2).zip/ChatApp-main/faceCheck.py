from deepface import DeepFace
import cv2

# "Facenet", "ArcFace", "VGG-Face", or "Dlib"
def compare_faces(img1_path, img2_path, model_name="Facenet", threshold=0.6):
    try:
        result = DeepFace.verify(img1_path=img1_path, img2_path=img2_path, model_name=model_name, enforce_detection=True)
        similarity = result["distance"]
        verified = result["verified"]
        print(f"Similarity score: {similarity:.4f}")
        return "Same person ✅" if verified else "Different person ❌"
    except Exception as e:
        return f"Error: {str(e)}"

# Example usage
img1 = "Achu.png"
img2 = "Achu2.png"
print(compare_faces(img1, img2))
