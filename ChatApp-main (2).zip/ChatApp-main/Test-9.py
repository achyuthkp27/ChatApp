import json
import logging
import os
import re
import time
import warnings
from typing import List, Dict, Tuple

import fitz  # PyMuPDF
import numpy as np
import requests
from flask import Flask, request, jsonify
from flask_cors import CORS

warnings.filterwarnings("ignore")

# ----------------- Config -----------------
USE_QDRANT = bool(os.environ.get("QDRANT_URL"))
QDRANT_URL = os.environ.get("QDRANT_URL", "")
QDRANT_COLLECTION = os.environ.get("QDRANT_COLLECTION", "bank_kb")

try:
    import faiss

    HAS_FAISS = True
except Exception:
    HAS_FAISS = False

try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import PointStruct

    HAS_QDRANT_CLIENT = True
except Exception:
    HAS_QDRANT_CLIENT = False

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyCcYJknjfIS9VCFgrTainOfpDM3jim2fc0")
GEMINI_GEN_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
GEMINI_EMBED_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-embedding-001:embedContent"
VERIFY_SSL = False  # set True if your environment has valid certs

PDF_PATH = os.environ.get("RETAIL_PDF", "summary.pdf")
CHUNK_SIZE = int(os.environ.get("CHUNK_SIZE", 800))  # semantic chunk max length
TOP_K = int(os.environ.get("TOP_K", 6))  # retrieval candidates before rerank
HISTORY_TOKEN_BUDGET = int(os.environ.get("HISTORY_TOKEN_BUDGET", 800))  # words approximation
CONTEXT_TOKEN_BUDGET = int(os.environ.get("CONTEXT_TOKEN_BUDGET", 1500))  # words approximation
MAX_USER_QUERY_TOKENS = int(os.environ.get("MAX_USER_QUERY_TOKENS", 120))
MAX_RESPONSE_TOKENS = int(os.environ.get("MAX_RESPONSE_TOKENS", 250))

DISCLAIMER = "\n\nNote: This assistant cannot handle sensitive account actions. Please use official channels for transactions."

logging.basicConfig(level=logging.INFO, filename="chatbot.log", format="%(asctime)s %(levelname)s %(message)s")
app = Flask(__name__)
CORS(app)

# ----------------- Global state (no sessions) -----------------
CHUNKS: List[Dict] = []  # [{id, text}]
EMBED_MATRIX = None  # np.ndarray (normalized)
EMBED_DIM = None
FAISS_INDEX = None
QDRANT_CLIENT = None

# Lightweight shared history and threads (optional, without sessions)
CHAT_HISTORY: List[Dict] = []  # [{role, text}]
THREADS: List[List[Dict]] = []  # list of previous summarized threads

# ----------------- Security -----------------
PII_PATTERNS = [re.compile(r"\b\d{12}\b"),  # Aadhaar-like
                re.compile(r"\b\d{16}\b"),  # card number-like
                re.compile(r"\b\d{10}\b"),  # phone-like
                re.compile(r"[\w\.-]+@[\w\.-]+")  # email
                ]
INJECTION_BAITS = [re.compile(r"(?i)ignore previous instructions"), re.compile(r"(?i)you are now .* assistant"),
                   re.compile(r"(?i)reveal the system prompt"), ]
# Replace with a proper profanity list or library in production
PROFANITY_LIST = {"badword1", "badword2", "badword3"}


# ----------------- Sanitization & validation -----------------
def redact_pii(text: str) -> Tuple[str, List[str]]:
    hits = []
    out = text
    for p in PII_PATTERNS:
        matches = p.findall(out)
        if matches:
            hits.extend(matches)
        out = p.sub("[REDACTED]", out)
    return out, hits


def strip_injection_bait(text: str) -> str:
    t = text
    for p in INJECTION_BAITS:
        t = p.sub("", t)
    return t.strip()


def validate_input(user_text: str) -> Tuple[bool, str]:
    if not user_text.strip():
        return False, "empty_input"
    if len(user_text.split()) > MAX_USER_QUERY_TOKENS:
        return False, "query_too_long"
    if any(word.lower() in PROFANITY_LIST for word in re.findall(r"\w+", user_text.lower())):
        return False, "profanity_detected"
    # Simple nonsensical/repetitive check: too few unique tokens relative to length
    tokens = re.findall(r"\w+", user_text.lower())
    if len(tokens) >= 6 and len(set(tokens)) < 3:
        return False, "nonsensical_input"
    return True, ""


# ----------------- Observability -----------------
def log_chat_event(event_type: str, user_text: str, answer: str = "", error: str = "", meta: Dict = None):
    payload = {"event": event_type, "timestamp": int(time.time()), "query_length": len(user_text.split()),
               "response_length": len(answer.split()) if answer else 0, "error": error, }
    if meta:
        payload.update(meta)
    logging.info(json.dumps(payload))


# ----------------- Resilience -----------------
CIRCUIT_OPEN = False
FAIL_COUNT = 0
MAX_FAILS = 3
COOLDOWN = 60
LAST_FAIL_TS = 0


def call_gemini_with_resilience(prompt: str) -> str:
    global CIRCUIT_OPEN, FAIL_COUNT, LAST_FAIL_TS
    if CIRCUIT_OPEN and time.time() - LAST_FAIL_TS < COOLDOWN:
        return "I'm temporarily unavailable. Please try again later or contact support."

    headers = {"Content-Type": "application/json"}
    params = {"key": GEMINI_API_KEY}
    body = {"contents": [{"parts": [{"text": prompt}]}]}

    for attempt in range(3):
        try:
            t0 = time.time()
            resp = requests.post(GEMINI_GEN_URL, params=params, json=body, timeout=25, verify=VERIFY_SSL)
            latency_ms = int((time.time() - t0) * 1000)
            resp.raise_for_status()
            text = resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
            FAIL_COUNT = 0
            CIRCUIT_OPEN = False
            log_chat_event("gemini_generation_success", prompt[:120], text[:120], meta={"latency_ms": latency_ms})
            return text
        except Exception as e:
            FAIL_COUNT += 1
            LAST_FAIL_TS = time.time()
            log_chat_event("gemini_generation_error", prompt[:120], error=str(e), meta={"attempt": attempt + 1})
            time.sleep(2 ** attempt)

    if FAIL_COUNT >= MAX_FAILS:
        CIRCUIT_OPEN = True
    return "I can’t fetch that right now. Please try again later or reach support."


def gemini_embed(texts: List[str]) -> List[List[float]]:
    headers = {"Content-Type": "application/json"}
    params = {"key": GEMINI_API_KEY}
    embeddings = []
    for i, text in enumerate(texts):
        body = {"model": "models/gemini-embedding-001", "content": {"parts": [{"text": text}]}}
        for attempt in range(3):
            try:
                t0 = time.time()
                resp = requests.post(GEMINI_EMBED_URL, headers=headers, params=params, json=body, timeout=25,
                                     verify=VERIFY_SSL)
                latency_ms = int((time.time() - t0) * 1000)
                resp.raise_for_status()
                j = resp.json()
                vec = j["embedding"]["values"]
                embeddings.append(vec)
                log_chat_event("gemini_embedding_success", text[:80], meta={"latency_ms": latency_ms, "chunk_index": i})
                break
            except Exception as e:
                log_chat_event("gemini_embedding_error", text[:80], error=str(e),
                               meta={"attempt": attempt + 1, "chunk_index": i})
                time.sleep(2 ** attempt)
        else:
            # fallback random vector with fixed dim (1536 typical for model above)
            embeddings.append((np.random.randn(1536)).tolist())
    return embeddings


# ----------------- Helpers: UX polish -----------------
def summarize_text(text: str, purpose: str = "general") -> str:
    prompt = f"Summarize the following {purpose} concisely and clearly:\n\n{text}"
    return call_gemini_with_resilience(prompt)


def reformulate_question(user_query: str) -> str:
    prompt = ("Reformulate the following user input into a clear, direct banking question.\n"
              "Do not add extra information; keep original intent.\n\n"
              f"{user_query}")
    return call_gemini_with_resilience(prompt)


def enforce_tone(answer: str) -> str:
    # ensure polite closing
    closing_options = ["thank you.", "please let me know if you need more help."]
    if not any(answer.lower().strip().endswith(opt) for opt in closing_options):
        answer = answer.rstrip() + "\n\nThank you for banking with us."
    return answer


def append_disclaimer(answer: str) -> str:
    return answer + DISCLAIMER


# ----------------- PDF ingestion + semantic chunking -----------------
def load_pdf(path: str) -> str:
    doc = fitz.open(path)
    return "\n".join([page.get_text("text") for page in doc])


def semantic_chunk_text(text: str, max_chunk_size=CHUNK_SIZE) -> List[str]:
    text = re.sub(r"\r\n?", "\n", text)
    paragraphs = re.split(r"\n\s*\n", text)
    chunks = []
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(para) <= max_chunk_size:
            chunks.append(para)
        else:
            # split long paragraph into fixed-size pieces
            for i in range(0, len(para), max_chunk_size):
                piece = para[i:i + max_chunk_size].strip()
                if piece:
                    chunks.append(piece)
    logging.info(f"Semantic chunked into {len(chunks)} pieces")
    return chunks


# ----------------- Indexing (FAISS/Qdrant) -----------------
def init_qdrant_client():
    global QDRANT_CLIENT
    if not HAS_QDRANT_CLIENT:
        logging.warning("qdrant-client not installed; skipping Qdrant init")
        return
    QDRANT_CLIENT = QdrantClient(url=QDRANT_URL)
    try:
        QDRANT_CLIENT.recreate_collection(collection_name=QDRANT_COLLECTION,
                                          vectors_config={"size": EMBED_DIM, "distance": "Cosine"})
        logging.info("Qdrant collection ready")
    except Exception as e:
        logging.warning(f"Qdrant setup exception: {e}")


def index_to_qdrant(vectors: List[List[float]], chunks_meta: List[Dict]):
    if not QDRANT_CLIENT:
        return
    try:
        points = [PointStruct(id=meta["id"], vector=vec, payload={"text": meta["text"]}) for vec, meta in
                  zip(vectors, chunks_meta)]
        QDRANT_CLIENT.upsert(collection_name=QDRANT_COLLECTION, points=points)
        logging.info(f"Upserted {len(points)} Qdrant points")
    except Exception as e:
        logging.warning(f"Qdrant upsert failed: {e}")


def init_faiss_index(vectors: np.ndarray):
    global FAISS_INDEX
    if not HAS_FAISS:
        logging.warning("faiss not installed; skipping FAISS init")
        return
    dim = vectors.shape[1]
    idx = faiss.IndexFlatIP(dim)
    FAISS_INDEX = idx
    FAISS_INDEX.add(vectors)
    logging.info(f"FAISS index populated ({vectors.shape[0]} entries)")


def build_index_from_pdf(pdf_path: str):
    global CHUNKS, EMBED_MATRIX, EMBED_DIM
    doc = load_pdf(pdf_path)
    raw_chunks = semantic_chunk_text(doc, max_chunk_size=CHUNK_SIZE)
    CHUNKS = [{"id": f"chunk_{i}", "text": c} for i, c in enumerate(raw_chunks)]
    vectors = gemini_embed([c["text"] for c in CHUNKS])
    vecs = np.array(vectors, dtype=np.float32)
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    vecs = vecs / (norms + 1e-12)

    EMBED_MATRIX = vecs
    EMBED_DIM = vecs.shape[1]

    if USE_QDRANT and HAS_QDRANT_CLIENT:
        init_qdrant_client()
        index_to_qdrant(vecs.tolist(), CHUNKS)
    elif HAS_FAISS:
        init_faiss_index(vecs)
    else:
        logging.error("No index method available (install faiss or set QDRANT_URL)")


# ----------------- Retrieval -----------------
def search_faiss(query_vec: np.ndarray, top_k=TOP_K) -> List[Tuple[int, float]]:
    if FAISS_INDEX is None:
        return []
    if query_vec.ndim == 1:
        query_vec = query_vec.reshape(1, -1)
    faiss.normalize_L2(query_vec)
    D, I = FAISS_INDEX.search(query_vec, top_k)
    return list(zip(I[0].tolist(), D[0].tolist()))


def search_qdrant(query_vec: List[float], top_k=TOP_K) -> List[Tuple[str, float, Dict]]:
    if not QDRANT_CLIENT:
        return []
    res = QDRANT_CLIENT.search(collection_name=QDRANT_COLLECTION, query_vector=query_vec, limit=top_k)
    return [(r.id, r.score, r.payload) for r in res]


def retrieve_chunks_by_embedding(query: str, top_k=TOP_K) -> List[Dict]:
    q_vecs = gemini_embed([query])
    qv = np.array(q_vecs, dtype=np.float32)[0]
    qv = qv / (np.linalg.norm(qv) + 1e-12)

    chunks_out = []
    if USE_QDRANT and HAS_QDRANT_CLIENT and QDRANT_CLIENT:
        results = search_qdrant(qv.tolist(), top_k=top_k)
        for id_, score, payload in results:
            chunks_out.append({"id": id_, "text": payload.get("text", ""), "score": float(score)})
    elif HAS_FAISS and FAISS_INDEX is not None:
        hits = search_faiss(qv, top_k=top_k)
        for idx, score in hits:
            if 0 <= idx < len(CHUNKS):
                ct = CHUNKS[idx]["text"]
                chunks_out.append({"id": CHUNKS[idx]["id"], "text": ct, "score": float(score)})
    else:
        logging.error("No retrieval method available")
    return chunks_out


# ----------------- Reranking & context selection -----------------
def rerank_chunks(query: str, candidates: List[Dict]) -> List[Dict]:
    if not candidates:
        return []
    context_text = "\n\n".join([f"[{i}] {c['text']}" for i, c in enumerate(candidates)])
    prompt = f"""
You are a reranker. Given a user query and candidate passages, rank them by relevance.

Query: {query}

Candidates:
{context_text}

Return ONLY a JSON list of candidate indices in order of most relevant first.
Example: [2, 0, 1]
""".strip()
    try:
        text = call_gemini_with_resilience(prompt)
        order = json.loads(text)
        reranked = [candidates[i] for i in order if isinstance(i, int) and 0 <= i < len(candidates)]
        return reranked if reranked else candidates
    except Exception as e:
        logging.warning(f"Rerank failed: {e}")
        return candidates


def select_context_chunks(query: str, candidates: List[Dict], max_tokens=CONTEXT_TOKEN_BUDGET) -> List[Dict]:
    selected = []
    token_count = len(query.split())
    for c in candidates:
        c_tokens = len(c["text"].split())
        if token_count + c_tokens > max_tokens:
            break
        selected.append(c)
        token_count += c_tokens
    return selected


# ----------------- History management without sessions -----------------
def add_to_history(role: str, text: str):
    global CHAT_HISTORY, THREADS
    CHAT_HISTORY.append({"role": role, "text": text})
    # Trim if too long by summarizing the entire thread
    total_words = sum(len(m["text"].split()) for m in CHAT_HISTORY)
    if total_words > HISTORY_TOKEN_BUDGET:
        summary = summarize_text("\n".join(m["text"] for m in CHAT_HISTORY), purpose="thread")
        THREADS.append(CHAT_HISTORY.copy())
        CHAT_HISTORY = [{"role": "system", "text": f"Summary of previous thread: {summary}"}]


def navigate_threads(keyword: str) -> str:
    for thread in reversed(THREADS):
        if any(keyword.lower() in m["text"].lower() for m in thread):
            return "\n".join(f"{m['role']}: {m['text']}" for m in thread)
    return ""


# ----------------- Prompt template -----------------
def build_prompt(context_text: str, user_question: str, mode: str = "detailed") -> str:
    # Include last few turns from CHAT_HISTORY (lightweight, no sessions)
    recent_history = "\n".join(f"{m['role'].capitalize()}: {m['text']}" for m in CHAT_HISTORY[-6:])
    detail_instruction = "Answer in 2-4 short paragraphs with bullet points where helpful." if mode == "detailed" else "Answer briefly in 3-5 concise sentences."

    prompt = f"""
You are Annie, the official, friendly, and professional Virtual Assistant for First Citizens Bank.
Maintain highest standards of trust, security, and compliance. Never request, reveal, or reference any confidential data (PIN, CVV, account numbers, passwords, OTP, address, etc.).
Answer strictly using the CONTEXT and recent CONVERSATION HISTORY. If unsure, say so and suggest contacting official support.

{detail_instruction}

CONTEXT:
{context_text}

CONVERSATION HISTORY:
{recent_history}

CUSTOMER QUESTION:
{user_question}

Annie’s Response:
""".strip()
    return prompt


# ----------------- Chat route -----------------
@app.route("/chat", methods=["POST"])
def chat():
    payload = request.get_json(force=True)
    user_text_raw = payload.get("message", "")
    mode = payload.get("mode", "detailed")  # "summary" or "detailed"
    thread_keyword = payload.get("thread_keyword")  # optional: "loans", etc. for navigation

    # Sanitize
    user_text, pii_hits = redact_pii(user_text_raw)
    user_text = strip_injection_bait(user_text)

    # Validate
    valid, error = validate_input(user_text)
    if not valid:
        log_chat_event("validation_error", user_text, error=error)
        return jsonify({"error": error}), 400

    # Optional thread navigation hint (fetch prior thread and append as system note)
    if thread_keyword:
        prior = navigate_threads(thread_keyword)
        if prior:
            add_to_history("system", f"Recalled prior thread for keyword '{thread_keyword}':\n{prior[:400]}")

    # Store user turn (summarized if long)
    summarized_for_history = summarize_text(user_text, purpose="query") if len(user_text.split()) > 60 else user_text
    add_to_history("user", summarized_for_history)

    # Summarize & reformulate for retrieval/generation
    summarized_query = summarize_text(user_text, purpose="query")
    clean_question = reformulate_question(summarized_query)

    # Retrieve context
    candidates = retrieve_chunks_by_embedding(clean_question, top_k=TOP_K)

    # Clarification strategy if low confidence
    if candidates and max(c["score"] for c in candidates) < 0.30:
        log_chat_event("clarification_triggered", user_text, meta={"max_score": max(c["score"] for c in candidates)})
        return jsonify(
            {"type": "clarification", "message": "Did you mean account balance, fund transfer, or cheque services?",
             "options": ["Account balance", "Fund transfer", "Cheque services"]})

    # Rerank and context selection
    candidates = rerank_chunks(clean_question, candidates)
    selected = select_context_chunks(clean_question, candidates, max_tokens=CONTEXT_TOKEN_BUDGET)
    if not selected:
        add_to_history("assistant", "I couldn't find relevant info in the current documents.")
        return jsonify({"type": "faq", "answer": "I couldn't find relevant info in retail docs.", "citations": [],
                        "pii_redacted": bool(pii_hits), })

    context_text = "\n\n---\n\n".join([c["text"] for c in selected])

    # Build prompt and call Gemini (resilient)
    prompt = build_prompt(context_text, clean_question, mode=mode)
    answer = call_gemini_with_resilience(prompt)

    # Tone & disclaimers
    answer = enforce_tone(answer)
    answer = append_disclaimer(answer)

    # Summarize long responses for history
    store_text = answer if len(answer.split()) <= MAX_RESPONSE_TOKENS else summarize_text(answer, purpose="response")
    add_to_history("assistant", store_text)

    # Citations with snippets
    citations = [{"id": c["id"], "snippet": (c["text"][:160] + "...") if len(c["text"]) > 160 else c["text"]} for c in
                 selected]

    log_chat_event("chat_success", user_text, answer, meta={"citations_count": len(citations)})

    return jsonify({"type": "faq", "answer": answer,  # full answer to user
                    "citations": citations, "pii_redacted": bool(pii_hits), })


# ----------------- Health route -----------------
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"ok": True, "ts": int(time.time()), "chunks_indexed": len(CHUNKS)})


# ----------------- Main -----------------
if __name__ == "__main__":
    if not GEMINI_API_KEY:
        raise SystemExit("Set GEMINI_API_KEY environment variable before running.")
    if not os.path.exists(PDF_PATH):
        raise SystemExit(f"Missing PDF at {PDF_PATH}. Set RETAIL_PDF env var to your document path.")
    logging.info("Building index from PDF...")
    build_index_from_pdf(PDF_PATH)
    logging.info(f"Ready. Serving on 0.0.0.0:{int(os.environ.get('PORT', 5000))}")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
