import face_recognition

def compare_faces(img1_path, img2_path, threshold=0.6):
    img1 = face_recognition.load_image_file(img1_path)
    img2 = face_recognition.load_image_file(img2_path)

    encodings1 = face_recognition.face_encodings(img1)
    encodings2 = face_recognition.face_encodings(img2)

    if not encodings1 or not encodings2:
        return "Face not detected in one or both images."

    # Compare first face in each image
    distance = face_recognition.face_distance([encodings1[0]], encodings2[0])[0]
    print(f"Distance: {distance:.4f}")

    return "Same person ✅" if distance < threshold else "Different person ❌"

# Example usage
img1 = "Achu.png"
img2 = "Achu2.png"
print(compare_faces(img1, img2))
