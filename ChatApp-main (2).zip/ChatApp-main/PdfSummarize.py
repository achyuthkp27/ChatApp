import os

import fitz
import requests
from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer

GEMINI_GEN_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
API_KEY = "AIzaSyCcYJknjfIS9VCFgrTainOfpDM3jim2fc0"
VERIFY_SSL = False
PDF_PATH = os.environ.get("RETAIL_PDF", "retail.pdf")


def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    full_text = ""
    for page in doc:
        full_text += page.get_text()
    return full_text


def load_pdf(path: str) -> str:
    doc = fitz.open(path)
    return "\n".join([page.get_text("text") for page in doc])


def summarize_with_gemini(text, prompt):
    params = {"key": API_KEY}
    body = {"contents": [{"parts": [{"text": prompt + "\n\n" + text}]}]}
    response = requests.post(GEMINI_GEN_URL, params=params, json=body, timeout=20, verify=VERIFY_SSL)

    response.raise_for_status()
    return response.json()["candidates"][0]["content"]["parts"][0]["text"]


def write_summary_to_pdf(summary, output_path):
    doc = SimpleDocTemplate(output_path, pagesize=LETTER)
    styles = getSampleStyleSheet()
    story = []

    for line in summary.split("\n"):
        if line.strip():  # Skip empty lines
            para = Paragraph(line.strip(), styles["Normal"])
            story.append(para)
            story.append(Spacer(1, 12))  # Add space between paragraphs

    doc.build(story)


# === Usage ===
pdf_path = "retail.pdf"
output_path = "summary.pdf"
prompt = """Act as a professional summarizer for an enterprise RAG system. Your task is to generate a **concept-rich, executive-style summary** of the following document that:

- **Covers all essential information** — retain every key fact, insight, and conclusion.  
- **Consolidates duplication** — merge repeated ideas into single, well-formed sentences.  
- **Ensures clarity** — rewrite unclear or incomplete sentences so they convey precise meaning.  
- **Organizes logically** — structure the summary into coherent paragraphs with clear topic flow.  
- **Optimizes for retrieval** — use terminology and concepts from the source text to support semantic search.  
- **Preserves references** — include all navigation elements and website links in full.  

If multiple points belong to the same topic, merge them into continuous prose rather than bullet points.  
Output only the summary in plain text (no markdown, no lists)."""

text = extract_text_from_pdf(pdf_path)
test = load_pdf(PDF_PATH)
summary = summarize_with_gemini(test, prompt)
write_summary_to_pdf(summary, output_path)
