import cv2
import numpy as np
import insightface
from insightface.app import FaceAnalysis

# Initialize InsightFace with CPU-only ONNX backend
app = FaceAnalysis(providers=['CPUExecutionProvider'])
app.prepare(ctx_id=0, det_size=(640, 640))

def get_embedding(image_path):
    img = cv2.imread(image_path)
    faces = app.get(img)
    if not faces:
        print(f"No face detected in {image_path}")
        return None
    return faces[0].embedding


def compare_faces(img1_path, img2_path, threshold=0.6):
    emb1 = get_embedding(img1_path)
    emb2 = get_embedding(img2_path)
    if emb1 is None or emb2 is None:
        return "Face not detected in one or both images."

    similarity = np.dot(emb1, emb2) / (np.linalg.norm(emb1) * np.linalg.norm(emb2))
    print(f"Similarity score: {similarity:.4f}")
    return "Same person ✅" if similarity > threshold else "Different person ❌"


# Example usage
img1 = "Achu.png"
img2 = "Achu2.png"
print(compare_faces(img1, img2))
