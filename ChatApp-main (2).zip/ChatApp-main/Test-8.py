import json
import logging
import os
import re
import time
import warnings
from typing import List, Dict, Tuple

import fitz
import numpy as np
import requests
from flask import Flask, request, jsonify
from flask_cors import CORS
from langdetect import detect, LangDetectException

warnings.filterwarnings("ignore")

# ----------------- Config -----------------
USE_QDRANT = bool(os.environ.get("QDRANT_URL"))
QDRANT_URL = os.environ.get("QDRANT_URL", "")
QDRANT_COLLECTION = os.environ.get("QDRANT_COLLECTION", "bank_kb")

try:
    import faiss

    HAS_FAISS = True
except Exception:
    HAS_FAISS = False

try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import PointStruct

    HAS_QDRANT_CLIENT = True
except Exception:
    HAS_QDRANT_CLIENT = False

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyCcYJknjfIS9VCFgrTainOfpDM3jim2fc0")
GEMINI_GEN_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"
VERIFY_SSL = False

PDF_PATH = os.environ.get("RETAIL_PDF", "summary.pdf")
CHUNK_SIZE = 800
TOP_K = 5
HISTORY_TOKEN_BUDGET = 800
CONTEXT_TOKEN_BUDGET = 1500
MAX_USER_QUERY_TOKENS = 120
MAX_RESPONSE_TOKENS = 250

DISCLAIMER = "\n\nNote: This assistant cannot handle sensitive account actions. Please use official channels for transactions."

logging.basicConfig(level=logging.INFO, filename="chatbot.log", format="%(asctime)s %(levelname)s %(message)s")
app = Flask(__name__)
CORS(app)

# ----------------- State -----------------
CHUNKS: List[Dict] = []
EMBED_MATRIX = None
FAISS_INDEX = None
QDRANT_CLIENT = None
EMBED_DIM = None

# ----------------- Security -----------------
PII_PATTERNS = [re.compile(r"\b\d{12}\b"), re.compile(r"\b\d{16}\b"), re.compile(r"\b\d{10}\b"),
                re.compile(r"[\w\.-]+@[\w\.-]+")]
INJECTION_BAITS = [re.compile(r"(?i)ignore previous instructions"), re.compile(r"(?i)you are now .* assistant"),
                   re.compile(r"(?i)reveal the system prompt"), ]
PROFANITY_LIST = {"badword1", "badword2"}


# ----------------- Sanitization -----------------
def redact_pii(text: str) -> Tuple[str, List[str]]:
    hits = []
    out = text
    for p in PII_PATTERNS:
        for m in p.findall(out):
            hits.append(m)
        out = p.sub("[REDACTED]", out)
    return out, hits


def strip_injection_bait(text: str) -> str:
    t = text
    for p in INJECTION_BAITS:
        t = p.sub("", t)
    return t.strip()


def validate_input(user_text: str) -> Tuple[bool, str]:
    if not user_text.strip():
        return False, "empty_input"
    if len(user_text.split()) > MAX_USER_QUERY_TOKENS:
        return False, "query_too_long"
    try:
        lang = detect(user_text)
        # if lang != "en":
        #     return False, "unsupported_language"
    except LangDetectException:
        return False, "language_detection_failed"
    if any(word.lower() in PROFANITY_LIST for word in user_text.split()):
        return False, "profanity_detected"
    if len(set(user_text.split())) < 3:
        return False, "nonsensical_input"
    return True, ""


# ----------------- Helpers -----------------
def summarize_text(text: str, purpose: str = "general") -> str:
    prompt = f"Summarize the following {purpose} concisely:\n\n{text}"
    return call_gemini_with_resilience(prompt)


def reformulate_question(user_query: str) -> str:
    prompt = f"Reformulate into a clear banking question:\n\n{user_query}"
    return call_gemini_with_resilience(prompt)


def enforce_tone(answer: str) -> str:
    if not answer.lower().endswith(("thank you.", "please let me know if you need more help.")):
        answer += "\n\nThank you for banking with us."
    return answer


def append_disclaimer(answer: str) -> str:
    return answer + DISCLAIMER


def log_chat_event(event_type: str, user_text: str, answer: str, error: str = ""):
    logging.info(json.dumps({"event": event_type, "timestamp": int(time.time()), "query_length": len(user_text.split()),
                             "response_length": len(answer.split()) if answer else 0, "error": error}))


# ----------------- Resilience -----------------
CIRCUIT_OPEN = False
FAIL_COUNT = 0
MAX_FAILS = 3
COOLDOWN = 60
LAST_FAIL_TS = 0


def call_gemini_with_resilience(prompt: str) -> str:
    global CIRCUIT_OPEN, FAIL_COUNT, LAST_FAIL_TS
    if CIRCUIT_OPEN and time.time() - LAST_FAIL_TS < COOLDOWN:
        return "I'm temporarily unavailable. Please try again later or contact support."
    for attempt in range(3):
        try:
            headers = {"Content-Type": "application/json"}
            params = {"key": GEMINI_API_KEY}
            body = {"contents": [{"parts": [{"text": prompt}]}]}
            resp = requests.post(GEMINI_GEN_URL, params=params, json=body, timeout=20, verify=VERIFY_SSL)
            resp.raise_for_status()
            text = resp.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
            FAIL_COUNT = 0
            return text
        except Exception as e:
            FAIL_COUNT += 1
            LAST_FAIL_TS = time.time()
            time.sleep(2 ** attempt)
    if FAIL_COUNT >= MAX_FAILS:
        CIRCUIT_OPEN = True
    return "I can’t fetch that right now. Please try again later or reach support."


# ----------------- Embeddings & Retrieval -----------------
def load_pdf(path: str) -> str:
    doc = fitz.open(path)
    return "\n".join([page.get_text("text") for page in doc])


def semantic_chunk_text(text: str, max_chunk_size=CHUNK_SIZE) -> List[str]:
    paragraphs = re.split(r"\n\s*\n", text)
    chunks = []
    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(para) <= max_chunk_size:
            chunks.append(para)
        else:
            for i in range(0, len(para), max_chunk_size):
                chunks.append(para[i:i + max_chunk_size])
    return chunks


def gemini_embed(texts: List[str]) -> List[List[float]]:
    GEMINI_EMBED_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-embedding-001:embedContent"
    headers = {"Content-Type": "application/json"}
    params = {"key": GEMINI_API_KEY}
    embeddings = []
    for text in texts:
        try:
            body = {"model": "models/gemini-embedding-001", "content": {"parts": [{"text": text}]}}
            resp = requests.post(GEMINI_EMBED_URL, headers=headers, params=params, json=body, timeout=20,
                                 verify=VERIFY_SSL)
            resp.raise_for_status()
            j = resp.json()
            embeddings.append(j["embedding"]["values"])
        except Exception:
            embeddings.append(np.random.randn(1536).tolist())
    return embeddings


def build_index_from_pdf(pdf_path: str):
    global CHUNKS, EMBED_MATRIX, EMBED_DIM, FAISS_INDEX
    doc = load_pdf(pdf_path)
    raw_chunks = semantic_chunk_text(doc)
    CHUNKS = [{"id": f"chunk_{i}", "text": c} for i, c in enumerate(raw_chunks)]
    vectors = gemini_embed([c["text"] for c in CHUNKS])
    vecs = np.array(vectors, dtype=np.float32)
    norms = np.linalg.norm(vecs, axis=1, keepdims=True)
    vecs = vecs / (norms + 1e-12)
    EMBED_MATRIX = vecs
    EMBED_DIM = vecs.shape[1]
    if HAS_FAISS:
        idx = faiss.IndexFlatIP(EMBED_DIM)
        idx.add(vecs)
        globals()["FAISS_INDEX"] = idx


def search_faiss(query_vec: np.ndarray, top_k=TOP_K):
    if query_vec.ndim == 1:
        query_vec = query_vec.reshape(1, -1)
    faiss.normalize_L2(query_vec)
    D, I = FAISS_INDEX.search(query_vec, top_k)
    return list(zip(I[0].tolist(), D[0].tolist()))


def search_qdrant(query_vec: List[float], top_k=TOP_K):
    res = QDRANT_CLIENT.search(collection_name=QDRANT_COLLECTION, query_vector=query_vec, limit=top_k)
    return [(r.id, r.score, r.payload) for r in res]


def retrieve_chunks_by_embedding(query: str, top_k=TOP_K) -> List[Dict]:
    q_vecs = gemini_embed([query])
    qv = np.array(q_vecs, dtype=np.float32)[0]
    qv = qv / (np.linalg.norm(qv) + 1e-12)

    chunks_out = []
    if USE_QDRANT and HAS_QDRANT_CLIENT:
        results = search_qdrant(qv.tolist(), top_k=top_k)
        for id_, score, payload in results:
            chunks_out.append({"id": id_, "text": payload.get("text", ""), "score": float(score)})
    elif HAS_FAISS:
        hits = search_faiss(qv, top_k=top_k)
        for idx, score in hits:
            if idx < 0 or idx >= len(CHUNKS):
                continue
            ct = CHUNKS[idx]["text"]
            chunks_out.append({"id": CHUNKS[idx]["id"], "text": ct, "score": float(score)})
    return chunks_out


@app.route("/chat", methods=["POST"])
def chat():
    payload = request.get_json(force=True)
    user_text_raw = payload.get("message", "")

    # Sanitize
    user_text, pii_hits = redact_pii(user_text_raw)
    user_text = strip_injection_bait(user_text)

    # Validate
    valid, error = validate_input(user_text)
    if not valid:
        return jsonify({"error": error}), 400

    # Summarize & reformulate
    summarized_query = summarize_text(user_text, purpose="query")
    clean_question = reformulate_question(summarized_query)

    # Retrieve context
    candidates = retrieve_chunks_by_embedding(clean_question, top_k=TOP_K)

    if candidates and max(c["score"] for c in candidates) < 0.3:
        return jsonify(
            {"type": "clarification", "message": "Did you mean account balance, fund transfer, or cheque services?"})

    context_text = "\n\n---\n\n".join([c["text"] for c in candidates])

    # Build prompt
    prompt = f"Context:\n{context_text}\n\nUser question:\n{clean_question}\n\nAnswer clearly and politely."

    # Call Gemini
    answer = call_gemini_with_resilience(prompt)
    answer = enforce_tone(answer)
    answer = append_disclaimer(answer)

    # Summarize long responses
    if len(answer.split()) > MAX_RESPONSE_TOKENS:
        answer = summarize_text(answer, purpose="response")

    log_chat_event("chat", user_text, answer)

    return jsonify({"type": "faq", "answer": answer,
                    "citations": [{"id": c["id"], "snippet": c["text"][:120]} for c in candidates],
                    "pii_redacted": bool(pii_hits)})


if __name__ == "__main__":
    if not GEMINI_API_KEY:
        raise SystemExit("Set GEMINI_API_KEY environment variable before running.")
    if not os.path.exists(PDF_PATH):
        raise SystemExit(f"Missing PDF at {PDF_PATH}")
    logging.info("Building index from PDF...")
    build_index_from_pdf(PDF_PATH)
    logging.info("Ready. Serving on 0.0.0.0:5000")
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
