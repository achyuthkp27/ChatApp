
"""
INTENT RECOGNITION COMPARISON DEMO
=================================
This demo shows the difference between the original regex-based intent detection
and the improved deep learning approach.
"""

import re
from typing import Dict, List
from deep_learning_intent_system import BankingIntentData, DeepLearningIntentClassifier, EnhancedIntentAnalyzer

class OriginalRegexIntentDetection:
    """Original regex-based intent detection (problematic approach)"""

    def detect_intent(self, text: str) -> str:
        """Simple regex-based intent detection - the problematic original approach"""
        text_lower = text.lower()

        # Simple keyword matching - causes false positives
        if "balance" in text_lower:
            return "account_balance_check"
        elif "transfer" in text_lower or "send money" in text_lower:
            return "fund_transfer"
        elif "cheque book" in text_lower or "checkbook" in text_lower:
            return "order_cheque_book"
        elif "stop cheque" in text_lower or "stop check" in text_lower:
            return "stop_cheque"
        else:
            return "faq"

class IntentComparisonDemo:
    """Demo class to compare intent detection approaches"""

    def __init__(self):
        self.original_detector = OriginalRegexIntentDetection()
        self.setup_deep_learning_model()

        # Test cases that demonstrate the problems with regex approach
        self.test_cases = [
            # Cases where user asks about information (should be FAQ) but regex gives wrong intent
            {
                'text': 'What is the stop cheque fee?',
                'expected_intent': 'FAQ_INQUIRY',
                'expected_action': False,
                'description': 'User asking about stop cheque fee (information request, not action)'
            },
            {
                'text': 'How much does it cost to stop a cheque?',
                'expected_intent': 'FAQ_INQUIRY', 
                'expected_action': False,
                'description': 'User asking about stop cheque cost (information request)'
            },
            {
                'text': 'What are the transfer charges?',
                'expected_intent': 'FAQ_INQUIRY',
                'expected_action': False, 
                'description': 'User asking about transfer fees (information request)'
            },
            {
                'text': 'How do I check my account balance?',
                'expected_intent': 'FAQ_INQUIRY',
                'expected_action': False,
                'description': 'User asking how to check balance (information request)'
            },
            {
                'text': 'What is the minimum balance required?',
                'expected_intent': 'FAQ_INQUIRY',
                'expected_action': False,
                'description': 'User asking about balance requirements (information request)'
            },

            # Cases where user wants to actually DO something (should be action intents)
            {
                'text': 'I want to stop cheque number 123456',
                'expected_intent': 'STOP_CHEQUE',
                'expected_action': True,
                'description': 'User wants to stop a specific cheque (action request)'
            },
            {
                'text': 'Please stop my cheque',
                'expected_intent': 'STOP_CHEQUE',
                'expected_action': True,
                'description': 'User requesting to stop their cheque (action request)'
            },
            {
                'text': 'Show me my account balance',
                'expected_intent': 'ACCOUNT_BALANCE_CHECK',
                'expected_action': True,
                'description': 'User wants to see their balance (action request)'
            },
            {
                'text': 'Transfer $500 to account 12345',
                'expected_intent': 'FUND_TRANSFER',
                'expected_action': True,
                'description': 'User wants to transfer money (action request)'
            },
            {
                'text': 'I need a new cheque book',
                'expected_intent': 'ORDER_CHEQUE_BOOK',
                'expected_action': True,
                'description': 'User wants to order cheque book (action request)'
            },

            # Edge cases that are tricky
            {
                'text': 'Can you help me understand the stop cheque process?',
                'expected_intent': 'FAQ_INQUIRY',
                'expected_action': False,
                'description': 'User asking about process (information request despite action words)'
            },
            {
                'text': 'My balance is low, what should I do?',
                'expected_intent': 'FAQ_INQUIRY',
                'expected_action': False,
                'description': 'User asking for advice (information request despite "balance" keyword)'
            },
        ]

    def setup_deep_learning_model(self):
        """Setup and train the deep learning model for comparison"""
        print("Setting up Deep Learning Intent Recognition Model...")

        # Initialize components
        self.dl_classifier = DeepLearningIntentClassifier()

        # Get training data
        data_provider = BankingIntentData()
        texts, labels = data_provider.get_training_data()

        print(f"Training model with {len(texts)} examples...")

        # Train the model (using fewer epochs for demo speed)
        self.dl_classifier.train(texts, labels, epochs=20, validation_split=0.2)

        # Initialize enhanced analyzer
        self.dl_analyzer = EnhancedIntentAnalyzer(self.dl_classifier)

        print("✅ Deep Learning model trained and ready!")

    def run_comparison_demo(self):
        """Run the comparison demo"""
        print("\n" + "="*80)
        print("INTENT RECOGNITION COMPARISON DEMO")
        print("="*80)
        print("Comparing Original Regex Approach vs Deep Learning Approach")
        print("="*80)

        correct_original = 0
        correct_deep_learning = 0

        for i, test_case in enumerate(self.test_cases, 1):
            text = test_case['text']
            expected_intent = test_case['expected_intent']
            expected_action = test_case['expected_action']
            description = test_case['description']

            print(f"\n[TEST CASE {i}]")
            print(f"Input: \"{text}\"")
            print(f"Description: {description}")
            print(f"Expected: {expected_intent} (Action: {expected_action})")
            print("-" * 60)

            # Original regex approach
            original_intent = self.original_detector.detect_intent(text)
            original_correct = (original_intent.upper() == expected_intent)

            print(f"❌ ORIGINAL (Regex): {original_intent}")
            if original_correct:
                print("   ✅ CORRECT")
                correct_original += 1
            else:
                print("   ❌ INCORRECT - This is the problem with regex matching!")

            # Deep learning approach  
            dl_analysis = self.dl_analyzer.analyze_intent(text)
            dl_intent = dl_analysis['intent']
            dl_action = dl_analysis['is_action_request']
            dl_confidence = dl_analysis['confidence']

            dl_intent_correct = (dl_intent == expected_intent)
            dl_action_correct = (dl_action == expected_action)
            dl_correct = dl_intent_correct and dl_action_correct

            print(f"✅ DEEP LEARNING: {dl_intent} (Action: {dl_action}, Confidence: {dl_confidence:.2f})")
            if dl_correct:
                print("   ✅ CORRECT - Understands user's actual intent!")
                correct_deep_learning += 1
            else:
                print("   ⚠️  INCORRECT - Needs more training data for this case")

            if dl_analysis['extracted_entities']:
                print(f"   📋 Entities: {dl_analysis['extracted_entities']}")

            print(f"   🤔 Reasoning: {dl_analysis['reasoning']}")

        # Summary
        print("\n" + "="*80)
        print("COMPARISON RESULTS")
        print("="*80)

        total_tests = len(self.test_cases)
        original_accuracy = (correct_original / total_tests) * 100
        dl_accuracy = (correct_deep_learning / total_tests) * 100

        print(f"Original Regex Approach:")
        print(f"   Correct: {correct_original}/{total_tests}")
        print(f"   Accuracy: {original_accuracy:.1f}%")
        print(f"   Problems: Simple keyword matching causes false positives")

        print(f"\nDeep Learning Approach:")
        print(f"   Correct: {correct_deep_learning}/{total_tests}")
        print(f"   Accuracy: {dl_accuracy:.1f}%")
        print(f"   Benefits: Understands context and user intent, not just keywords")

        improvement = dl_accuracy - original_accuracy
        print(f"\n🎯 IMPROVEMENT: {improvement:+.1f}% accuracy increase!")

        print("\n" + "="*80)
        print("KEY INSIGHTS")
        print("="*80)

        print("❌ Problems with Original Regex Approach:")
        print("   • 'What is the stop cheque fee?' → Incorrectly classified as STOP_CHEQUE")
        print("   • 'How much does transfer cost?' → Incorrectly classified as FUND_TRANSFER") 
        print("   • Simple keyword matching without context understanding")
        print("   • Cannot distinguish between asking ABOUT something vs DOING something")
        print("   • High false positive rate for banking operations")

        print("\n✅ Benefits of Deep Learning Approach:")
        print("   • Understands the difference between information requests and actions")
        print("   • Considers full sentence context, not just keywords")
        print("   • Provides confidence scores for predictions")
        print("   • Extracts relevant entities (amounts, account numbers, etc.)")
        print("   • Can be improved with more training data")
        print("   • Explains reasoning behind classifications")

        print("\n🏦 Banking Application Impact:")
        print("   • Prevents incorrect routing of customer requests")
        print("   • Improves customer satisfaction with accurate responses")
        print("   • Reduces manual intervention needed")
        print("   • Enables more sophisticated conversational flows")
        print("   • Better compliance with banking regulations")

        return {
            'original_accuracy': original_accuracy,
            'deep_learning_accuracy': dl_accuracy,
            'improvement': improvement,
            'total_tests': total_tests
        }

if __name__ == "__main__":
    print("🏦 BANKING APPLICATION INTENT RECOGNITION DEMO")
    print("This demo shows why deep learning is better than regex for banking applications")
    print("\nInitializing demo... (This may take a few minutes to train the model)")

    demo = IntentComparisonDemo()
    results = demo.run_comparison_demo()

    print(f"\n✅ Demo completed!")
    print(f"The deep learning approach achieved {results['improvement']:+.1f}% better accuracy")
    print("This demonstrates why neural networks are essential for accurate intent recognition in banking applications.")
