
"""
DEEP LEARNING INTENT RECOGNITION FOR BANKING APPLICATION
========================================================
This system uses a neural network to classify user intents instead of simple regex matching.
It provides much more accurate intent detection for banking operations.
"""

import os
import re
import json
import uuid
import logging
import pickle
import numpy as np
from typing import List, Dict, Tuple, Optional
from datetime import datetime, timedelta

import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout, Embedding, LSTM, GlobalMaxPooling1D
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# ============= BANKING INTENT TRAINING DATA =============
class BankingIntentData:
    """Training data for banking intent classification"""

    def __init__(self):
        self.intents = {
            'ACCOUNT_BALANCE_CHECK': [
                'What is my account balance?',
                'Show me my current balance',
                'Check my account balance',
                'How much money do I have?',
                'What is my available balance?',
                'Display my balance',
                'I want to see my balance',
                'Can you check my balance?',
                'What is my current account balance?',
                'How much is in my account?',
                'Show my account balance',
                'I need to check my balance',
                'What is my balance right now?',
                'Can I see my current balance?',
                'Tell me my account balance',
                'I want to know my balance',
                'Check balance in my savings account',
                'What is my checking account balance?',
                'Show current balance',
                'Balance inquiry please'
            ],
            'FUND_TRANSFER': [
                'Transfer money to another account',
                'I want to send money',
                'Transfer $500 to account 12345',
                'Send money to my friend',
                'I need to transfer funds',
                'Move money from savings to checking',
                'Transfer amount to beneficiary',
                'Send $100 to account number 67890',
                'I want to make a transfer',
                'Transfer money to spouse account',
                'Send payment to vendor',
                'Wire transfer to another bank',
                'Internal transfer between accounts',
                'Pay someone through transfer',
                'Move funds to external account',
                'Transfer money online',
                'I need to send money urgently',
                'Make a payment transfer',
                'Transfer to family member',
                'Send money via NEFT'
            ],
            'STOP_CHEQUE': [
                'Stop cheque number 123456',
                'I want to cancel my cheque',
                'Stop payment on cheque',
                'Cancel cheque that I issued',
                'Block my cheque from processing',
                'I need to stop a cheque',
                'Prevent cheque from being cashed',
                'Stop the cheque I wrote yesterday',
                'Cancel cheque payment',
                'I want to stop my cheque number 789',
                'Block cheque number 456123',
                'Stop payment on the cheque',
                'I issued a cheque but want to stop it',
                'Prevent cheque encashment',
                'Stop cheque immediately',
                'I need to cancel a cheque',
                'Block my cheque from clearing',
                'Stop payment request for cheque',
                'I want to void my cheque',
                'Cancel the cheque I wrote'
            ],
            'ORDER_CHEQUE_BOOK': [
                'I need a new cheque book',
                'Order cheque book',
                'I want to order cheque book',
                'Can I get a new checkbook?',
                'Request for new cheque book',
                'I need more cheques',
                'Order a cheque book please',
                'I want to request cheque book',
                'Can you send me a new cheque book?',
                'I need to order checks',
                'Please send me a cheque book',
                'I want a fresh cheque book',
                'Order new checkbook',
                'I need cheque book delivered',
                'Can I order more cheques?',
                'Request cheque book',
                'I want to get a cheque book',
                'Order personalized cheques',
                'I need blank cheques',
                'Send me a new cheque book'
            ],
            'FAQ_INQUIRY': [
                'What is the stop cheque fee?',
                'How much does it cost to stop a cheque?',
                'What are the transfer charges?',
                'How do I check my balance online?',
                'What is the minimum balance required?',
                'How to activate mobile banking?',
                'What are your branch timings?',
                'How to apply for credit card?',
                'What documents needed for loan?',
                'How to update my phone number?',
                'What is the interest rate on savings?',
                'How to close my account?',
                'What are the ATM withdrawal limits?',
                'How to register for internet banking?',
                'What is the IFSC code of your branch?',
                'How to get account statement?',
                'What are the charges for cheque book?',
                'How to change my address?',
                'What is customer care number?',
                'How to block my ATM card?',
                'What are fixed deposit rates?',
                'How to open joint account?',
                'What is the process for loan application?',
                'How to get duplicate passbook?',
                'What documents needed for account opening?'
            ]
        }

    def get_training_data(self) -> Tuple[List[str], List[str]]:
        """Get training data as texts and labels"""
        texts = []
        labels = []

        for intent, examples in self.intents.items():
            for example in examples:
                texts.append(example.lower())  # Normalize to lowercase
                labels.append(intent)

        return texts, labels

    def get_intent_descriptions(self) -> Dict[str, str]:
        """Get human-readable descriptions for each intent"""
        return {
            'ACCOUNT_BALANCE_CHECK': 'User wants to check their account balance',
            'FUND_TRANSFER': 'User wants to transfer money to another account', 
            'STOP_CHEQUE': 'User wants to stop/cancel a specific cheque',
            'ORDER_CHEQUE_BOOK': 'User wants to order a new cheque book',
            'FAQ_INQUIRY': 'User is asking questions about banking services or policies'
        }

# ============= DEEP LEARNING INTENT CLASSIFIER =============
class DeepLearningIntentClassifier:
    """Neural network based intent classifier for banking"""

    def __init__(self, max_sequence_length: int = 20, max_vocab_size: int = 1000):
        self.max_sequence_length = max_sequence_length
        self.max_vocab_size = max_vocab_size
        self.tokenizer = None
        self.label_encoder = None
        self.model = None
        self.is_trained = False

    def build_model(self, vocab_size: int, num_classes: int) -> Sequential:
        """Build the neural network architecture"""
        model = Sequential([
            # Embedding layer to convert words to dense vectors
            Embedding(vocab_size, 128, input_length=self.max_sequence_length),

            # LSTM layer to understand sequence patterns
            LSTM(64, dropout=0.2, recurrent_dropout=0.2),

            # Dense layers for classification
            Dense(32, activation='relu'),
            Dropout(0.3),
            Dense(16, activation='relu'), 
            Dropout(0.2),

            # Output layer
            Dense(num_classes, activation='softmax')
        ])

        model.compile(
            optimizer='adam',
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )

        return model

    def preprocess_texts(self, texts: List[str]) -> np.ndarray:
        """Convert texts to sequences of integers"""
        if self.tokenizer is None:
            self.tokenizer = Tokenizer(num_words=self.max_vocab_size, oov_token='<OOV>')
            self.tokenizer.fit_on_texts(texts)

        sequences = self.tokenizer.texts_to_sequences(texts)
        padded_sequences = pad_sequences(sequences, maxlen=self.max_sequence_length, padding='post')

        return padded_sequences

    def train(self, texts: List[str], labels: List[str], validation_split: float = 0.2, epochs: int = 50):
        """Train the intent classification model"""
        logging.info(f"Training intent classifier with {len(texts)} examples")

        # Preprocess data
        X = self.preprocess_texts(texts)

        # Encode labels
        self.label_encoder = LabelEncoder()
        y = self.label_encoder.fit_transform(labels)

        # Build model
        vocab_size = len(self.tokenizer.word_index) + 1
        num_classes = len(self.label_encoder.classes_)

        self.model = self.build_model(vocab_size, num_classes)

        # Train model
        history = self.model.fit(
            X, y,
            validation_split=validation_split,
            epochs=epochs,
            batch_size=32,
            verbose=1,
            callbacks=[
                tf.keras.callbacks.EarlyStopping(patience=10, restore_best_weights=True),
                tf.keras.callbacks.ReduceLROnPlateau(patience=5)
            ]
        )

        self.is_trained = True
        logging.info("Intent classifier training completed")

        return history

    def predict_intent(self, text: str, return_confidence: bool = True) -> Dict:
        """Predict intent for a given text"""
        if not self.is_trained or self.model is None:
            raise ValueError("Model must be trained before prediction")

        # Preprocess the input text
        processed_text = self.preprocess_texts([text.lower()])

        # Get prediction probabilities
        predictions = self.model.predict(processed_text, verbose=0)
        predicted_class_idx = np.argmax(predictions[0])
        confidence = float(predictions[0][predicted_class_idx])

        # Convert back to label
        predicted_intent = self.label_encoder.inverse_transform([predicted_class_idx])[0]

        # Get all probabilities for analysis
        all_probabilities = {}
        for i, class_name in enumerate(self.label_encoder.classes_):
            all_probabilities[class_name] = float(predictions[0][i])

        result = {
            'intent': predicted_intent,
            'confidence': confidence,
            'all_probabilities': all_probabilities,
            'is_confident': confidence > 0.7,  # Confidence threshold
            'prediction_method': 'deep_learning'
        }

        return result

    def save_model(self, model_path: str, tokenizer_path: str, encoder_path: str):
        """Save the trained model and preprocessors"""
        if self.model is not None:
            self.model.save(model_path)

        if self.tokenizer is not None:
            with open(tokenizer_path, 'wb') as f:
                pickle.dump(self.tokenizer, f)

        if self.label_encoder is not None:
            with open(encoder_path, 'wb') as f:
                pickle.dump(self.label_encoder, f)

        logging.info(f"Model saved: {model_path}")

    def load_model(self, model_path: str, tokenizer_path: str, encoder_path: str):
        """Load pre-trained model and preprocessors"""
        if os.path.exists(model_path):
            self.model = load_model(model_path)
            self.is_trained = True

        if os.path.exists(tokenizer_path):
            with open(tokenizer_path, 'rb') as f:
                self.tokenizer = pickle.load(f)

        if os.path.exists(encoder_path):
            with open(encoder_path, 'rb') as f:
                self.label_encoder = pickle.load(f)

        logging.info(f"Model loaded from: {model_path}")

# ============= ENHANCED INTENT ANALYZER =============
class EnhancedIntentAnalyzer:
    """Enhanced intent analyzer with entity extraction and confidence analysis"""

    def __init__(self, classifier: DeepLearningIntentClassifier):
        self.classifier = classifier
        self.entity_patterns = {
            'amount': r'\$?([0-9]{1,3}(?:,?[0-9]{3})*(?:\.[0-9]{2})?)',
            'account_number': r'\b([0-9]{8,16})\b',
            'cheque_number': r'\b(?:cheque|check)\s*(?:number|#)?\s*([0-9]{4,8})\b',
            'account_type': r'\b(savings|current|checking)\s*account\b'
        }

    def analyze_intent(self, text: str) -> Dict:
        """Comprehensive intent analysis with entities and context"""
        # Get basic intent prediction
        intent_result = self.classifier.predict_intent(text)

        # Extract entities
        entities = self.extract_entities(text)

        # Determine if this is an action request vs information request
        is_action_request = self.is_action_request(text, intent_result['intent'])

        # Generate reasoning
        reasoning = self.generate_reasoning(text, intent_result, entities, is_action_request)

        return {
            'intent': intent_result['intent'],
            'confidence': intent_result['confidence'],
            'is_confident': intent_result['is_confident'],
            'all_probabilities': intent_result['all_probabilities'],
            'extracted_entities': entities,
            'is_action_request': is_action_request,
            'reasoning': reasoning,
            'suggested_response_type': 'action' if is_action_request else 'information',
            'analysis_method': 'deep_learning_enhanced'
        }

    def extract_entities(self, text: str) -> Dict:
        """Extract relevant entities from the text"""
        entities = {}

        for entity_type, pattern in self.entity_patterns.items():
            matches = re.finditer(pattern, text, re.IGNORECASE)
            values = [match.group(1) for match in matches]
            if values:
                entities[entity_type] = values[0] if len(values) == 1 else values

        return entities

    def is_action_request(self, text: str, predicted_intent: str) -> bool:
        """Determine if the text is requesting an action vs asking for information"""

        # Action words that indicate user wants to DO something
        action_indicators = [
            'transfer', 'send', 'move', 'pay', 'stop', 'cancel', 'block',
            'order', 'request', 'get me', 'i want to', 'i need to',
            'can you', 'please', 'help me', 'i would like'
        ]

        # Information words that indicate user wants to KNOW something  
        info_indicators = [
            'what is', 'what are', 'how much', 'how do i', 'how to',
            'tell me', 'explain', 'information about', 'details about',
            'cost', 'fee', 'charge', 'rate', 'process', 'procedure'
        ]

        text_lower = text.lower()

        # Count indicators
        action_score = sum(1 for indicator in action_indicators if indicator in text_lower)
        info_score = sum(1 for indicator in info_indicators if indicator in text_lower)

        # For FAQ_INQUIRY, bias towards information unless strong action indicators
        if predicted_intent == 'FAQ_INQUIRY':
            return action_score > info_score + 1

        # For other intents, bias towards action unless strong information indicators  
        else:
            return action_score >= info_score

    def generate_reasoning(self, text: str, intent_result: Dict, entities: Dict, is_action: bool) -> str:
        """Generate human-readable reasoning for the classification"""
        intent = intent_result['intent']
        confidence = intent_result['confidence']

        reasoning = f"Classified as {intent} with {confidence:.1%} confidence. "

        if entities:
            entity_desc = ', '.join([f"{k}: {v}" for k, v in entities.items()])
            reasoning += f"Extracted entities: {entity_desc}. "

        if is_action:
            reasoning += "Identified as action request - user wants to perform an operation."
        else:
            reasoning += "Identified as information request - user wants to learn about something."

        return reasoning

print("✅ Deep Learning Intent Recognition System Created!")
print("Features:")
print("- Neural Network with LSTM for sequence understanding")
print("- Comprehensive training data for banking intents") 
print("- Entity extraction from user messages")
print("- Confidence scoring and action vs information detection")
print("- Production-ready intent classification")
