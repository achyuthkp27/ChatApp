# Create an improved Flask banking application with intelligent intent detection using Gemini Flash 2.0
improved_banking_app_intelligent = '''
"""
INTELLIGENT BANKING APPLICATION WITH GEMINI FLASH 2.0 INTENT DETECTION
=====================================================================
This application uses Gemini Flash 2.0 for intelligent intent detection 
instead of simple regex patterns to understand user's actual needs.
"""

from __future__ import annotations
import os
import re
import time
import json
import uuid
import logging
import hashlib
import secrets
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from functools import wraps

import fitz
import requests
import numpy as np
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import base64

from flask import Flask, request, jsonify, session, g
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman
from flask_wtf.csrf import CSRFProtect

# Optional libs (faiss or qdrant)
try:
    import faiss
    HAS_FAISS = True
except ImportError:
    HAS_FAISS = False

try:
    from qdrant_client import QdrantClient
    from qdrant_client.models import PointStruct, Distance
    HAS_QDRANT_CLIENT = True
except ImportError:
    HAS_QDRANT_CLIENT = False

# ============= SECURE CONFIGURATION =============
class BankingConfig:
    """Secure configuration management for banking application"""
    
    def __init__(self):
        # Required environment variables
        required_vars = ['GEMINI_API_KEY', 'SECRET_KEY']
        self.config = {}
        
        for var in required_vars:
            value = os.environ.get(var)
            if not value:
                raise ValueError(f"Required environment variable {var} not found")
            self.config[var] = value
        
        # Optional configuration with secure defaults
        self.config.update({
            'CHUNK_SIZE': int(os.environ.get('CHUNK_SIZE', '800')),
            'CHUNK_OVERLAP': int(os.environ.get('CHUNK_OVERLAP', '200')),
            'TOP_K': int(os.environ.get('TOP_K', '5')),
            'PDF_PATH': os.environ.get('RETAIL_PDF', 'retail_faq.pdf'),
            'ENVIRONMENT': os.environ.get('ENVIRONMENT', 'development'),
            'MAX_REQUESTS_PER_MINUTE': int(os.environ.get('MAX_REQUESTS_PER_MINUTE', '60')),
        })
    
    def get(self, key: str, default=None):
        return self.config.get(key, default)

config = BankingConfig()

# ============= GEMINI API INTEGRATION =============
class GeminiAPI:
    """Secure Gemini API client for intent detection and content generation"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models"
        self.model = "gemini-2.0-flash"
        self.embed_model = "gemini-embedding-001"
        
        # Setup session with proper SSL verification
        self.session = requests.Session()
        self.session.headers.update({
            'Content-Type': 'application/json'
        })
    
    def detect_user_intent(self, user_message: str, conversation_context: List[Dict] = None) -> Dict:
        """
        Use Gemini Flash 2.0 to intelligently detect user intent
        Returns detailed intent analysis with confidence scores
        """
        
        # Define clear intent categories for banking
        intent_prompt = f'''
You are an expert banking assistant specialized in understanding customer intentions. 
Analyze the following user message and determine the user's ACTUAL intent, not just keyword matching.

User Message: "{user_message}"

Banking Intent Categories:
1. ACCOUNT_BALANCE_CHECK - User wants to check their account balance
2. FUND_TRANSFER - User wants to transfer money to another account
3. STOP_CHEQUE - User wants to stop/cancel a specific cheque they issued
4. ORDER_CHEQUE_BOOK - User wants to order a new cheque book
5. FAQ_INQUIRY - User is asking questions about banking services, fees, policies, or general information

Important Guidelines:
- If user asks "What is stop cheque fee?" or "How much does it cost to stop a cheque?" → This is FAQ_INQUIRY (asking about information)
- If user says "I want to stop cheque number 123456" or "Please stop my cheque" → This is STOP_CHEQUE (actual action request)
- If user asks "What are transfer charges?" → This is FAQ_INQUIRY (asking about information)
- If user says "Transfer $500 to account 12345" or "I want to send money" → This is FUND_TRANSFER (actual action request)
- If user asks "How to check balance?" → This is FAQ_INQUIRY (asking about information)
- If user says "Show my balance" or "What's my account balance?" → This is ACCOUNT_BALANCE_CHECK (actual action request)

Return your analysis in this EXACT JSON format:
{{
    "intent": "one of the 5 categories above",
    "confidence": 0.95,
    "reasoning": "Brief explanation of why you classified it this way",
    "extracted_entities": {{
        "amount": null or number,
        "account_number": null or "string", 
        "cheque_number": null or "string",
        "account_type": null or "savings/current"
    }},
    "is_action_request": true or false,
    "suggested_response_type": "information" or "action" or "clarification"
}}
'''
        
        try:
            url = f"{self.base_url}/{self.model}:generateContent"
            
            payload = {
                "contents": [
                    {
                        "role": "user", 
                        "parts": [{"text": intent_prompt}]
                    }
                ],
                "generationConfig": {
                    "temperature": 0.1,  # Low temperature for consistent intent detection
                    "topK": 1,
                    "topP": 0.1,
                    "maxOutputTokens": 500
                }
            }
            
            response = self.session.post(
                url, 
                json=payload,
                params={'key': self.api_key},
                timeout=30,
                verify=True  # Always verify SSL
            )
            response.raise_for_status()
            
            result = response.json()
            content = result["candidates"][0]["content"]["parts"][0]["text"]
            
            # Parse the JSON response from Gemini
            try:
                intent_analysis = json.loads(content.strip())
                return intent_analysis
            except json.JSONDecodeError:
                # Fallback if JSON parsing fails
                logging.warning(f"Failed to parse Gemini response: {content}")
                return self._fallback_intent_detection(user_message)
                
        except Exception as e:
            logging.error(f"Gemini intent detection failed: {str(e)}")
            return self._fallback_intent_detection(user_message)
    
    def _fallback_intent_detection(self, user_message: str) -> Dict:
        """Fallback intent detection if Gemini API fails"""
        message_lower = user_message.lower()
        
        # Simple but more intelligent fallback
        if any(phrase in message_lower for phrase in ['my balance', 'account balance', 'check balance', 'show balance']):
            intent = 'ACCOUNT_BALANCE_CHECK'
            is_action = True
        elif any(phrase in message_lower for phrase in ['transfer money', 'send money', 'transfer to', 'pay to']):
            intent = 'FUND_TRANSFER' 
            is_action = True
        elif any(phrase in message_lower for phrase in ['stop cheque', 'cancel cheque', 'stop my cheque', 'cancel my cheque']):
            intent = 'STOP_CHEQUE'
            is_action = True
        elif any(phrase in message_lower for phrase in ['order cheque book', 'new cheque book', 'cheque book order']):
            intent = 'ORDER_CHEQUE_BOOK'
            is_action = True
        else:
            intent = 'FAQ_INQUIRY'
            is_action = False
        
        return {
            "intent": intent,
            "confidence": 0.6,  # Lower confidence for fallback
            "reasoning": "Fallback detection used due to API unavailability",
            "extracted_entities": {},
            "is_action_request": is_action,
            "suggested_response_type": "action" if is_action else "information"
        }
    
    def generate_response(self, user_message: str, context: str, intent_analysis: Dict) -> str:
        """Generate intelligent response based on intent analysis"""
        
        response_prompt = f'''
You are Annie, a professional and helpful banking assistant. 

User Message: "{user_message}"
Intent Analysis: {json.dumps(intent_analysis, indent=2)}
Context Information: {context}

Based on the intent analysis, provide an appropriate response:

If intent is FAQ_INQUIRY:
- Provide helpful information from the context
- Be detailed and educational
- End with "Is there anything else I can help you with?"

If intent is an ACTION (ACCOUNT_BALANCE_CHECK, FUND_TRANSFER, STOP_CHEQUE, ORDER_CHEQUE_BOOK):
- Acknowledge the request professionally
- Explain the next steps for completing this action
- Mention any security requirements
- Be concise but helpful

Keep your response professional, helpful, and appropriate for a banking environment.
'''
        
        try:
            url = f"{self.base_url}/{self.model}:generateContent"
            
            payload = {
                "contents": [
                    {"role": "user", "parts": [{"text": response_prompt}]}
                ],
                "generationConfig": {
                    "temperature": 0.3,
                    "topK": 20,
                    "topP": 0.8,
                    "maxOutputTokens": 800
                }
            }
            
            response = self.session.post(
                url,
                json=payload, 
                params={'key': self.api_key},
                timeout=30,
                verify=True
            )
            response.raise_for_status()
            
            result = response.json()
            return result["candidates"][0]["content"]["parts"][0]["text"]
            
        except Exception as e:
            logging.error(f"Gemini response generation failed: {str(e)}")
            return "I apologize, but I'm having trouble processing your request right now. Please try again or contact customer support."
    
    def embed_text(self, texts: List[str]) -> List[List[float]]:
        """Generate embeddings for text using Gemini embedding model"""
        embeddings = []
        
        for text in texts:
            try:
                url = f"{self.base_url}/{self.embed_model}:embedContent"
                
                payload = {
                    "model": f"models/{self.embed_model}",
                    "content": {
                        "parts": [{"text": text}]
                    }
                }
                
                response = self.session.post(
                    url,
                    json=payload,
                    params={'key': self.api_key},
                    timeout=20,
                    verify=True
                )
                response.raise_for_status()
                
                result = response.json()
                embeddings.append(result["embedding"]["values"])
                
            except Exception as e:
                logging.error(f"Embedding failed for text: {str(e)}")
                # Return random embedding as fallback (not ideal but prevents crashes)
                embeddings.append([0.0] * 768)  # Gemini embedding dimension
        
        return embeddings

# Initialize Gemini API
gemini_api = GeminiAPI(config.get('GEMINI_API_KEY'))

# ============= INPUT VALIDATION AND SECURITY =============
class SecurityManager:
    """Enhanced security manager with PII protection and validation"""
    
    PII_PATTERNS = [
        (r'\\b\\d{12}\\b', 'AADHAAR'),
        (r'\\b\\d{16}\\b', 'CARD_NUMBER'),
        (r'\\b\\d{10}\\b', 'PHONE_NUMBER'),
        (r'[\\w\\.-]+@[\\w\\.-]+\\.[\\w]{2,}', 'EMAIL'),
        (r'\\b\\d{4}\\s*\\d{4}\\s*\\d{4}\\s*\\d{4}\\b', 'CARD_NUMBER_SPACED'),
    ]
    
    INJECTION_PATTERNS = [
        r'(?i)ignore\\s+previous\\s+instructions',
        r'(?i)you\\s+are\\s+now\\s+.*assistant',
        r'(?i)reveal\\s+the\\s+system\\s+prompt',
        r'(?i)<script[^>]*>.*</script>',
        r'(?i)(union|select|insert|delete|drop)\\s',
        r'(?i)javascript:',
    ]
    
    def validate_and_sanitize_input(self, text: str) -> Tuple[str, List[str], bool]:
        """
        Comprehensive input validation and sanitization
        Returns: (sanitized_text, pii_found, is_malicious)
        """
        if not text or not isinstance(text, str):
            return "", [], False
        
        # Check for injection attempts
        is_malicious = self._detect_injection(text)
        if is_malicious:
            logging.warning(f"Malicious input detected: {text[:100]}...")
            return "", [], True
        
        # Detect and redact PII
        sanitized_text, pii_found = self._redact_pii(text)
        
        # Additional sanitization
        sanitized_text = self._sanitize_special_chars(sanitized_text)
        
        return sanitized_text, pii_found, False
    
    def _detect_injection(self, text: str) -> bool:
        """Detect potential injection attempts"""
        for pattern in self.INJECTION_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        return False
    
    def _redact_pii(self, text: str) -> Tuple[str, List[str]]:
        """Detect and redact PII"""
        pii_found = []
        sanitized = text
        
        for pattern, pii_type in self.PII_PATTERNS:
            matches = re.finditer(pattern, sanitized)
            for match in matches:
                pii_found.append(f"{pii_type}:{match.group()}")
                sanitized = re.sub(pattern, f'[REDACTED_{pii_type}]', sanitized)
        
        return sanitized, pii_found
    
    def _sanitize_special_chars(self, text: str) -> str:
        """Sanitize potentially dangerous special characters"""
        # Remove or escape dangerous characters
        sanitized = re.sub(r'[<>"\\'&]', '', text)
        return sanitized.strip()

# Initialize security manager
security_manager = SecurityManager()

# ============= DOCUMENT PROCESSING AND RAG =============
class DocumentProcessor:
    """Process PDF documents and create searchable knowledge base"""
    
    def __init__(self, gemini_api: GeminiAPI):
        self.gemini_api = gemini_api
        self.chunks = []
        self.embeddings = None
        self.faiss_index = None
    
    def load_and_process_pdf(self, pdf_path: str):
        """Load PDF and create searchable chunks"""
        if not os.path.exists(pdf_path):
            logging.warning(f"PDF file not found: {pdf_path}")
            return
        
        try:
            # Extract text from PDF
            doc = fitz.open(pdf_path)
            full_text = ""
            for page in doc:
                full_text += page.get_text("text")
            doc.close()
            
            # Create chunks
            raw_chunks = self._create_chunks(full_text)
            self.chunks = []
            
            for i, chunk in enumerate(raw_chunks):
                if chunk.strip():  # Only add non-empty chunks
                    self.chunks.append({
                        "id": f"chunk_{i}",
                        "text": chunk.strip(),
                        "metadata": {"source": pdf_path, "chunk_index": i}
                    })
            
            # Generate embeddings
            if self.chunks:
                chunk_texts = [chunk["text"] for chunk in self.chunks]
                embeddings = self.gemini_api.embed_text(chunk_texts)
                self.embeddings = np.array(embeddings, dtype=np.float32)
                
                # Create FAISS index for similarity search
                if HAS_FAISS and len(embeddings) > 0:
                    dimension = len(embeddings[0])
                    self.faiss_index = faiss.IndexFlatIP(dimension)  # Inner product for cosine similarity
                    # Normalize embeddings for cosine similarity
                    faiss.normalize_L2(self.embeddings)
                    self.faiss_index.add(self.embeddings)
                
                logging.info(f"Processed {len(self.chunks)} chunks from {pdf_path}")
        
        except Exception as e:
            logging.error(f"Error processing PDF {pdf_path}: {str(e)}")
    
    def _create_chunks(self, text: str, chunk_size: int = None, overlap: int = None) -> List[str]:
        """Create overlapping text chunks"""
        if chunk_size is None:
            chunk_size = config.get('CHUNK_SIZE')
        if overlap is None:
            overlap = config.get('CHUNK_OVERLAP')
        
        # Clean text
        text = text.replace('\\r\\n', '\\n').replace('\\r', '\\n')
        
        chunks = []
        start = 0
        text_length = len(text)
        
        while start < text_length:
            end = min(start + chunk_size, text_length)
            chunk = text[start:end].strip()
            
            if chunk:
                chunks.append(chunk)
            
            start = end - overlap
            if start >= text_length:
                break
        
        return chunks
    
    def search_relevant_chunks(self, query: str, top_k: int = None) -> List[Dict]:
        """Search for relevant chunks using semantic similarity"""
        if top_k is None:
            top_k = config.get('TOP_K')
        
        if not self.chunks or not self.embeddings.size:
            return []
        
        try:
            # Get query embedding
            query_embeddings = self.gemini_api.embed_text([query])
            query_vector = np.array(query_embeddings, dtype=np.float32)
            
            if HAS_FAISS and self.faiss_index:
                # Normalize query vector
                faiss.normalize_L2(query_vector)
                
                # Search using FAISS
                scores, indices = self.faiss_index.search(query_vector, min(top_k, len(self.chunks)))
                
                results = []
                for score, idx in zip(scores[0], indices[0]):
                    if idx != -1 and idx < len(self.chunks):
                        chunk = self.chunks[idx].copy()
                        chunk["similarity_score"] = float(score)
                        results.append(chunk)
                
                return results
            
            else:
                # Fallback: simple similarity calculation
                similarities = []
                query_vec = query_vector[0]
                
                for i, chunk_embedding in enumerate(self.embeddings):
                    # Calculate cosine similarity
                    similarity = np.dot(query_vec, chunk_embedding) / (
                        np.linalg.norm(query_vec) * np.linalg.norm(chunk_embedding)
                    )
                    similarities.append((similarity, i))
                
                # Sort by similarity and return top_k
                similarities.sort(key=lambda x: x[0], reverse=True)
                
                results = []
                for similarity, idx in similarities[:top_k]:
                    chunk = self.chunks[idx].copy()
                    chunk["similarity_score"] = float(similarity)
                    results.append(chunk)
                
                return results
        
        except Exception as e:
            logging.error(f"Error searching chunks: {str(e)}")
            return []

# Initialize document processor
doc_processor = DocumentProcessor(gemini_api)

print("✅ Intelligent Banking Application Framework Created!")
print("Key Features:")
print("- Gemini Flash 2.0 powered intent detection")
print("- Secure configuration management") 
print("- Advanced input validation and PII protection")
print("- Semantic document search with embeddings")
print("- Production-ready security measures")
'''

# Save the intelligent banking framework
with open('intelligent_banking_app_framework.py', 'w', encoding='utf-8') as f:
    f.write(improved_banking_app_intelligent)

print("✅ Intelligent Banking Application Framework created!")
print("📄 Saved as: intelligent_banking_app_framework.py")