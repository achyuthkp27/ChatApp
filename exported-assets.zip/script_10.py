# Create comprehensive banking FAQ content and save as text (which can be converted to PDF)
banking_faq_content = '''
COMPREHENSIVE BANKING FAQ DOCUMENT
==================================

1. ACCOUNT SERVICES

Q: What types of accounts do you offer?
A: We offer several types of accounts to meet your financial needs:
- Savings Account: Earn interest on your deposits with easy access to funds
- Checking Account: Perfect for daily transactions with debit card and check-writing privileges
- Current Account: Designed for businesses and high-transaction customers
- Fixed Deposit Account: Lock in higher interest rates for a fixed period
- Joint Account: Share account access with family members or business partners

Q: What is the minimum balance required for different accounts?
A: Minimum balance requirements vary by account type:
- Savings Account: $100 minimum balance
- Checking Account: $25 minimum balance  
- Current Account: $500 minimum balance
- Fixed Deposit: $1,000 minimum deposit
- Premium Savings: $10,000 minimum balance with higher interest rates

Q: How do I open a new account?
A: To open a new account, you'll need:
- Valid government-issued photo ID (driver's license, passport, or state ID)
- Social Security number or Tax ID
- Proof of address (utility bill, lease agreement, or bank statement)
- Initial deposit (varies by account type)
- Employment verification for business accounts
Visit any branch or apply online at our website. Account approval typically takes 1-2 business days.

Q: How can I check my account balance?
A: You can check your account balance through several convenient methods:
- Online banking: Available 24/7 at our website
- Mobile app: Download our secure mobile banking app
- ATM: Use your debit card at any of our ATMs
- Phone banking: Call our automated phone system
- Text banking: Receive balance updates via SMS
- In-branch: Visit any branch location during business hours

2. ONLINE AND MOBILE BANKING

Q: How do I register for online banking?
A: To register for online banking:
1. Visit our website and click "Enroll in Online Banking"
2. Enter your account number and Social Security number
3. Create a unique username and strong password
4. Set up security questions for account protection
5. Verify your email address and phone number
6. Accept terms and conditions
Your online banking access will be activated immediately after verification.

Q: Is mobile banking secure?
A: Yes, our mobile banking uses multiple security layers:
- 256-bit SSL encryption for all data transmission
- Multi-factor authentication for login
- Biometric login options (fingerprint, face recognition)
- Automatic session timeout after inactivity
- Real-time fraud monitoring and alerts
- Device registration for added security
Never share your login credentials and always log out when finished.

Q: What can I do with mobile banking?
A: Our mobile banking app offers comprehensive features:
- Check account balances and transaction history
- Transfer money between your accounts
- Pay bills and schedule future payments
- Deposit checks using mobile check capture
- Find nearby ATMs and branch locations
- Set up account alerts and notifications
- Contact customer service through secure messaging
- Temporarily lock/unlock your debit card

3. TRANSFERS AND PAYMENTS

Q: How do I transfer money to another account?
A: You can transfer money through several methods:

Internal Transfers (between your accounts):
- Online banking: Instant transfers between your accounts
- Mobile app: Transfer funds on-the-go
- Phone banking: Automated transfer system
- In-branch: Speak with a teller

External Transfers (to other banks):
- ACH Transfer: 1-3 business days, low fees
- Wire Transfer: Same day, higher fees for urgent transfers
- Online Bill Pay: Schedule one-time or recurring payments
- Zelle: Instant transfers to enrolled recipients

International Transfers:
- Wire transfers with correspondent banks
- International money transfer services
- Foreign currency exchange available

Q: What are the fees for different types of transfers?
A: Transfer fees vary by type and urgency:
- Internal transfers: Free between your accounts
- ACH transfers: $3 per transfer for external accounts
- Domestic wire transfers: $25 outgoing, $15 incoming
- International wire transfers: $45 outgoing, $20 incoming
- Expedited transfers: Additional $10 for same-day processing
- Zelle transfers: Free for enrolled customers
- Stop payment fee: $35 per item

Q: What are the transfer limits?
A: Daily transfer limits help protect your account:
- Online/Mobile transfers: $5,000 per day
- ATM transfers: $1,000 per day  
- Wire transfers: $25,000 per day (can be increased upon request)
- Zelle transfers: $2,500 per day
- Bill payments: $10,000 per day
Higher limits available for business accounts and premium customers.

4. CHEQUE SERVICES

Q: How do I order a new cheque book?
A: Ordering a cheque book is easy:
- Online banking: Go to "Services" → "Order Cheque Book"
- Mobile app: Select "Account Services" → "Order Cheques"
- Phone: Call customer service at 1-800-BANKING
- In-branch: Request from any teller
- Automatic reorder: Set up when you have 10 cheques remaining

Cheque book options:
- Standard personal cheques: 50 cheques for $15
- Business cheques: 100 cheques for $25
- Premium design cheques: 50 cheques for $20
- Duplicate cheques: 50 cheques for $18
Delivery takes 7-10 business days to your registered address.

Q: What is the stop cheque fee and process?
A: Stop cheque service prevents a cheque from being processed:

Stop Cheque Fee: $35 per cheque

How to stop a cheque:
1. Call customer service immediately at 1-800-BANKING
2. Provide cheque number, amount, and payee name
3. Confirm your account details for verification
4. Pay the stop payment fee
5. Receive confirmation number for your records

Important notes:
- Stop payment must be requested before the cheque clears
- Stop payment orders are valid for 6 months
- You can renew the stop payment for an additional fee
- If cheque has already been processed, stop payment cannot be completed
- Business accounts may have different fee structures

Q: What should I do if my cheque book is lost or stolen?
A: If your cheque book is lost or stolen:
1. Contact customer service immediately
2. We'll place a stop payment on all unused cheques
3. Monitor your account for any unauthorized transactions
4. Order a new cheque book with new starting numbers
5. File a police report if theft is suspected
6. Update any automatic payments using the old cheques

5. FEES AND CHARGES

Q: What are your standard account fees?
A: Our fee structure is transparent and competitive:

Monthly Maintenance Fees:
- Basic Savings: $5 (waived with $300 minimum balance)
- Checking Account: $12 (waived with direct deposit)
- Premium Savings: $15 (waived with $10,000 balance)
- Business Account: $25 (waived with $5,000 balance)

Transaction Fees:
- ATM fees: $2.50 at non-network ATMs
- Overdraft fee: $35 per occurrence
- Foreign transaction fee: 3% of transaction amount
- Paper statement fee: $3 per month
- Excessive transaction fee: $10 after 6 withdrawals from savings

Other Fees:
- Account closure fee: $25 if closed within 6 months
- Returned item fee: $35 per item
- Account research fee: $25 per hour
- Copy of statement fee: $5 per statement

Q: How can I avoid account fees?
A: Many fees can be avoided by:
- Maintaining minimum balance requirements
- Setting up direct deposit for checking accounts
- Using network ATMs to avoid surcharges
- Opting for electronic statements instead of paper
- Setting up low balance alerts to avoid overdrafts
- Linking accounts for overdraft protection
- Choosing accounts that match your usage patterns

6. LOANS AND CREDIT

Q: What types of loans do you offer?
A: We offer various loan products for different needs:

Personal Loans:
- Unsecured personal loans: $1,000 to $50,000
- Debt consolidation loans: Competitive rates
- Home improvement loans: Up to $100,000
- Auto loans: New and used vehicle financing

Mortgage Loans:
- Conventional mortgages: 15 and 30-year terms
- FHA loans: Government-backed mortgages
- VA loans: For eligible veterans
- Refinancing options: Lower your current rate

Business Loans:
- Small business loans: Up to $500,000
- Equipment financing: For business equipment
- Commercial real estate loans
- Lines of credit: Flexible funding options

Q: What are current interest rates?
A: Interest rates vary by loan type and creditworthiness:
- Personal loans: 7.99% - 24.99% APR
- Auto loans: 3.99% - 15.99% APR (based on term and credit)
- Mortgages: Contact us for current rates (rates change daily)
- Home equity loans: 5.99% - 12.99% APR
- Business loans: 6.99% - 18.99% APR

Rates are subject to change and depend on:
- Credit score and history
- Loan amount and term
- Down payment (for secured loans)
- Debt-to-income ratio
- Current market conditions

7. CUSTOMER SERVICE AND SUPPORT

Q: What are your customer service hours?
A: We're here to help when you need us:

Phone Support:
- Monday - Friday: 7:00 AM - 9:00 PM
- Saturday: 8:00 AM - 6:00 PM  
- Sunday: 10:00 AM - 4:00 PM
- 24/7 automated phone system for basic services

Online Support:
- Live chat: Monday - Friday, 8:00 AM - 8:00 PM
- Email support: Response within 24 hours
- Secure messaging through online banking
- Social media support during business hours

Branch Hours:
- Monday - Friday: 9:00 AM - 5:00 PM
- Saturday: 9:00 AM - 2:00 PM (select locations)
- Sunday: Closed
- Extended hours at some locations

Q: How do I report fraudulent activity?
A: If you suspect fraudulent activity:
1. Call our fraud hotline immediately: 1-800-FRAUD-HELP
2. Available 24/7 for urgent fraud reports
3. Temporarily block your cards through mobile app
4. Review recent transactions for unauthorized activity
5. File a dispute for any fraudulent charges
6. Change your online banking password
7. Monitor your accounts closely for 30 days

We offer zero liability protection for unauthorized transactions reported promptly.

8. SECURITY AND PRIVACY

Q: How do you protect my personal information?
A: We use industry-leading security measures:

Data Protection:
- Advanced encryption for all transactions
- Secure data centers with 24/7 monitoring
- Regular security audits and updates
- Strict access controls for employee systems

Account Protection:
- Multi-factor authentication options
- Account monitoring for unusual activity
- Automatic account lockout after failed login attempts
- Secure password requirements

Privacy Commitment:
- We never sell your personal information
- Information sharing only as required by law
- Opt-out options for marketing communications
- Annual privacy notices explaining our policies

Q: What should I do if I suspect my account is compromised?
A: Take immediate action if you suspect compromise:
1. Change your online banking password immediately
2. Call customer service to report the suspected breach
3. Review all recent account activity
4. Consider placing a fraud alert on your credit reports
5. Monitor your accounts daily for unusual activity
6. Update passwords for other financial accounts
7. Consider identity theft protection services

9. INTERNATIONAL SERVICES

Q: Do you offer international banking services?
A: Yes, we provide comprehensive international services:

International Transfers:
- Wire transfers to over 200 countries
- Competitive exchange rates
- Same-day processing available
- Tracking capabilities for all transfers

Travel Services:
- Foreign currency exchange
- Travel notifications to prevent card blocks
- International ATM access through global networks
- Travel insurance options

For Business:
- Letters of credit for international trade
- Foreign exchange hedging
- Correspondent banking relationships
- Trade finance solutions

Contact our international services desk for detailed information and current rates.

10. DIGITAL WALLET AND PAYMENT SERVICES

Q: Do you support digital wallet services?
A: Yes, we support major digital wallet platforms:

Supported Wallets:
- Apple Pay for iPhone and Apple Watch
- Google Pay for Android devices
- Samsung Pay for Samsung devices
- PayPal integration for online payments

Benefits:
- Enhanced security through tokenization
- Contactless payments at millions of merchants
- Online shopping without sharing card details
- Transaction notifications in real-time

Setup Instructions:
1. Download the wallet app on your device
2. Add your bank debit or credit card
3. Verify through text message or phone call
4. Start making secure contactless payments

For technical support with digital wallets, contact our customer service team.

---

IMPORTANT CONTACT INFORMATION:

Customer Service: 1-800-BANKING (1-800-226-5464)
Fraud Hotline: 1-800-FRAUD-HELP (24/7)
International Services: 1-800-INTL-BANK
Website: www.yourbank.com
Mobile App: Download "YourBank Mobile" from app stores

This FAQ document is updated regularly. For the most current information, please visit our website or contact customer service.

Last Updated: January 2025
'''

# Save the banking FAQ content as a text file (can be converted to PDF)
with open('banking_faq_document.txt', 'w', encoding='utf-8') as f:
    f.write(banking_faq_content)

print("✅ Comprehensive Banking FAQ Document created!")
print("📄 Saved as: banking_faq_document.txt")
print("📌 Note: This text file can be easily converted to PDF using any word processor or online converter")

# Create requirements for the deep learning banking application
dl_requirements = '''# DEEP LEARNING BANKING APPLICATION REQUIREMENTS

# Core Flask Framework
Flask==3.0.0
Flask-CORS==4.0.0
Flask-Limiter==3.5.0
Werkzeug==3.0.1

# Deep Learning and ML
tensorflow==2.15.0
scikit-learn==1.3.2
numpy==1.24.4

# Text Processing 
nltk==3.8.1

# Data Processing
pandas==2.1.4

# HTTP Requests
requests==2.31.0

# PDF Processing
PyMuPDF==1.23.8

# Environment Management
python-dotenv==1.0.0

# Development Tools
pytest==7.4.3
black==23.11.0
flake8==6.1.0

# Production Server
gunicorn==21.2.0
'''

with open('requirements_deep_learning.txt', 'w', encoding='utf-8') as f:
    f.write(dl_requirements)

# Create environment variables template for deep learning app
dl_env_template = '''# ENVIRONMENT VARIABLES FOR DEEP LEARNING BANKING APP
# Copy to .env and fill in actual values

# Gemini API Configuration
GEMINI_API_KEY=your_gemini_api_key_here

# Flask Configuration
SECRET_KEY=your_secret_key_for_flask_sessions
FLASK_ENV=development

# Application Settings
BANKING_FAQ_PDF=banking_faq_document.pdf
MAX_REQUESTS_PER_MINUTE=60

# Model Configuration
MODEL_PATH=intent_model.h5
TOKENIZER_PATH=tokenizer.pkl
ENCODER_PATH=label_encoder.pkl

# Logging
LOG_LEVEL=INFO
'''

with open('.env_deep_learning_template', 'w', encoding='utf-8') as f:
    f.write(dl_env_template)

print("✅ Requirements and environment template created!")
print("📄 Requirements saved as: requirements_deep_learning.txt")
print("📄 Environment template saved as: .env_deep_learning_template")