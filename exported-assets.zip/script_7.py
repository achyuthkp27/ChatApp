# Create the main Flask application with intelligent intent detection
flask_main_app = '''
"""
INTELLIGENT BANKING FLASK APPLICATION
====================================
Main Flask application with Gemini Flash 2.0 powered intent detection
"""

from intelligent_banking_app_framework import *

# ============= FLASK APP SETUP =============
app = Flask(__name__)
app.config['SECRET_KEY'] = config.get('SECRET_KEY')

# Security extensions
CORS(app, origins=['http://localhost:3000'], supports_credentials=True)
CSRFProtect(app)

# Rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=[f"{config.get('MAX_REQUESTS_PER_MINUTE')} per minute"]
)

# Security headers
if config.get('ENVIRONMENT') == 'production':
    Talisman(app, force_https=True)

# ============= SESSION MANAGEMENT =============
SESSIONS = {}  # In production, use Redis or database

def create_session(user_data: Dict) -> str:
    """Create secure session"""
    session_id = secrets.token_urlsafe(32)
    SESSIONS[session_id] = {
        'user_data': user_data,
        'created_at': datetime.utcnow(),
        'last_activity': datetime.utcnow()
    }
    return session_id

def get_session(session_id: str) -> Optional[Dict]:
    """Get and validate session"""
    if session_id not in SESSIONS:
        return None
    
    session_data = SESSIONS[session_id]
    
    # Check session timeout (30 minutes)
    if datetime.utcnow() - session_data['last_activity'] > timedelta(minutes=30):
        del SESSIONS[session_id]
        return None
    
    # Update last activity
    session_data['last_activity'] = datetime.utcnow()
    return session_data

# ============= FLASK ROUTES =============
@app.errorhandler(429)
def ratelimit_handler(e):
    return jsonify({'error': 'Rate limit exceeded. Please try again later.'}), 429

@app.errorhandler(400)
def bad_request_handler(e):
    return jsonify({'error': 'Invalid request format'}), 400

@app.errorhandler(500)
def internal_error_handler(e):
    logging.error(f"Internal server error: {str(e)}")
    return jsonify({'error': 'Internal server error'}), 500

@app.route('/health', methods=['GET'])
@limiter.limit("10 per minute")
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '2.0.0',
        'gemini_model': 'gemini-2.0-flash'
    })

@app.route('/chat', methods=['POST'])
@limiter.limit("20 per minute") 
def intelligent_chat():
    """
    Intelligent chat endpoint with Gemini-powered intent detection
    """
    try:
        # Get request data
        payload = request.get_json(force=True)
        user_message = payload.get('message', '').strip()
        session_id = payload.get('session_id') or str(uuid.uuid4())[:16]
        
        if not user_message:
            return jsonify({'error': 'Message cannot be empty'}), 400
        
        # Validate and sanitize input
        sanitized_message, pii_found, is_malicious = security_manager.validate_and_sanitize_input(user_message)
        
        if is_malicious:
            logging.warning(f"Malicious input blocked in session {session_id}")
            return jsonify({
                'error': 'Invalid input detected',
                'session_id': session_id
            }), 400
        
        if not sanitized_message:
            return jsonify({
                'error': 'Message contains only invalid content',
                'session_id': session_id
            }), 400
        
        # Get or create session
        session_data = get_session(session_id)
        if not session_data:
            session_data = {'conversation_history': []}
            session_id = create_session(session_data)
        
        # Add user message to conversation history
        session_data['conversation_history'] = session_data.get('conversation_history', [])
        session_data['conversation_history'].append({
            'role': 'user', 
            'message': sanitized_message,
            'timestamp': datetime.utcnow().isoformat()
        })
        
        # Use Gemini for intelligent intent detection
        intent_analysis = gemini_api.detect_user_intent(
            sanitized_message,
            session_data.get('conversation_history', [])[-5:]  # Last 5 messages for context
        )
        
        # Log the interaction (no sensitive data)
        logging.info(f"Intent detected - Session: {session_id}, Intent: {intent_analysis['intent']}, Confidence: {intent_analysis['confidence']}")
        
        # Handle based on intent
        if intent_analysis['is_action_request']:
            response = handle_banking_action(intent_analysis, sanitized_message, session_id)
        else:
            response = handle_information_request(intent_analysis, sanitized_message, session_id)
        
        # Add assistant response to conversation history
        session_data['conversation_history'].append({
            'role': 'assistant',
            'message': response['answer'],
            'intent_analysis': intent_analysis,
            'timestamp': datetime.utcnow().isoformat()
        })
        
        # Update session
        SESSIONS[session_id] = session_data
        
        # Prepare final response
        final_response = {
            'answer': response['answer'],
            'intent_analysis': {
                'intent': intent_analysis['intent'],
                'confidence': intent_analysis['confidence'],
                'is_action_request': intent_analysis['is_action_request'],
                'suggested_response_type': intent_analysis['suggested_response_type']
            },
            'session_id': session_id,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if pii_found:
            final_response['privacy_notice'] = 'Some sensitive information was automatically redacted for your security.'
        
        return jsonify(final_response), 200
        
    except Exception as e:
        logging.error(f"Chat endpoint error: {str(e)}")
        return jsonify({
            'error': 'Unable to process your request. Please try again.',
            'session_id': session_id
        }), 500

def handle_banking_action(intent_analysis: Dict, user_message: str, session_id: str) -> Dict:
    """Handle banking action requests (balance check, transfer, etc.)"""
    
    intent = intent_analysis['intent']
    entities = intent_analysis.get('extracted_entities', {})
    
    if intent == 'ACCOUNT_BALANCE_CHECK':
        return {
            'type': 'banking_action',
            'action': 'balance_inquiry',
            'answer': """I can help you check your account balance. For security reasons, I'll need to verify your identity first.

To check your balance, please:
1. Provide your account number
2. Complete authentication (PIN/OTP)
3. I'll then display your current balance

Would you like to proceed with the balance inquiry?""",
            'next_steps': ['account_verification', 'balance_display'],
            'entities': entities
        }
    
    elif intent == 'FUND_TRANSFER':
        extracted_amount = entities.get('amount')
        extracted_account = entities.get('account_number')
        
        response_text = "I can help you transfer funds. For security, money transfers require additional verification.\\n\\n"
        
        if extracted_amount:
            response_text += f"Amount to transfer: ${extracted_amount}\\n"
        if extracted_account:
            response_text += f"Destination account: {extracted_account}\\n\\n"
        
        response_text += """To complete the transfer, I'll need:
1. Your account PIN for authentication
2. Recipient's complete account details
3. Transfer purpose/reference
4. OTP verification for final authorization

Would you like to proceed with the fund transfer process?"""
        
        return {
            'type': 'banking_action',
            'action': 'fund_transfer',
            'answer': response_text,
            'next_steps': ['authentication', 'recipient_details', 'otp_verification'],
            'entities': entities
        }
    
    elif intent == 'STOP_CHEQUE':
        cheque_number = entities.get('cheque_number')
        
        response_text = "I can help you stop a cheque. This will prevent the cheque from being processed if it hasn't been cashed yet.\\n\\n"
        
        if cheque_number:
            response_text += f"Cheque number to stop: {cheque_number}\\n\\n"
        
        response_text += """To stop the cheque, I'll need:
1. Your account PIN for verification  
2. Cheque number (if not provided)
3. Reason for stopping the cheque
4. Stop cheque fee will apply (typically $25)

Note: If the cheque has already been cashed, it cannot be stopped.

Would you like to proceed with stopping the cheque?"""
        
        return {
            'type': 'banking_action', 
            'action': 'stop_cheque',
            'answer': response_text,
            'next_steps': ['authentication', 'cheque_verification', 'fee_payment'],
            'entities': entities
        }
    
    elif intent == 'ORDER_CHEQUE_BOOK':
        return {
            'type': 'banking_action',
            'action': 'order_cheque_book', 
            'answer': """I can help you order a new cheque book. This usually takes 5-7 business days for delivery.

To order your cheque book, I'll need:
1. Your account PIN for verification
2. Delivery address confirmation
3. Cheque book type (personal/business)
4. Number of cheque leaves (25/50/100)

Standard processing fee applies (typically $15).

Would you like to proceed with ordering a cheque book?""",
            'next_steps': ['authentication', 'delivery_details', 'cheque_book_options'],
            'entities': entities
        }
    
    else:
        return {
            'type': 'error',
            'answer': "I'm not sure how to help with that specific banking action. Could you please clarify what you'd like to do?"
        }

def handle_information_request(intent_analysis: Dict, user_message: str, session_id: str) -> Dict:
    """Handle information requests using RAG with document search"""
    
    # Search for relevant information in documents
    relevant_chunks = doc_processor.search_relevant_chunks(user_message)
    
    if relevant_chunks:
        # Combine relevant chunks as context
        context = "\\n\\n".join([chunk['text'] for chunk in relevant_chunks[:3]])  # Top 3 chunks
        
        # Generate response using Gemini with context
        answer = gemini_api.generate_response(user_message, context, intent_analysis)
    else:
        # No relevant documents found
        context = "No specific documentation found for this query."
        answer = gemini_api.generate_response(user_message, context, intent_analysis)
    
    return {
        'type': 'information',
        'answer': answer,
        'sources': [chunk['id'] for chunk in relevant_chunks[:3]] if relevant_chunks else [],
        'context_used': bool(relevant_chunks)
    }

# ============= STARTUP INITIALIZATION =============
def initialize_app():
    """Initialize the banking application"""
    try:
        # Load and process FAQ PDF if available
        pdf_path = config.get('PDF_PATH')
        if os.path.exists(pdf_path):
            logging.info(f"Loading FAQ document: {pdf_path}")
            doc_processor.load_and_process_pdf(pdf_path)
        else:
            logging.warning(f"FAQ PDF not found at {pdf_path}")
        
        logging.info("Banking application initialized successfully")
        
    except Exception as e:
        logging.error(f"Failed to initialize application: {str(e)}")
        raise

# ============= MAIN APPLICATION =============
if __name__ == '__main__':
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('intelligent_banking.log'),
            logging.StreamHandler()
        ]
    )
    
    # Initialize application
    initialize_app()
    
    # Run the application
    if config.get('ENVIRONMENT') == 'production':
        logging.info("Starting banking application in PRODUCTION mode")
        app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
    else:
        logging.info("Starting banking application in DEVELOPMENT mode")
        app.run(host='127.0.0.1', port=5000, debug=True)
'''

# Save the main Flask application
with open('intelligent_banking_main.py', 'w', encoding='utf-8') as f:
    f.write(flask_main_app)

print("✅ Intelligent Banking Flask Application created!")
print("📄 Saved as: intelligent_banking_main.py")