# Create the main Flask application with secure endpoints
improved_flask_main = '''
"""
IMPROVED SECURE BANKING APPLICATION - MAIN FLASK APP
===================================================
This module contains the main Flask application with secure endpoints,
authentication, and proper API design following banking industry standards.
"""

# ============= FLASK APPLICATION SETUP =============
def create_secure_banking_app() -> Flask:
    """Factory function to create secure Flask application"""
    
    app = Flask(__name__)
    
    # Security Configuration
    app.config.update({
        'SECRET_KEY': config.get('SECRET_KEY'),
        'SESSION_TYPE': 'redis',
        'SESSION_REDIS': redis.from_url(config.get('REDIS_URL')),
        'SESSION_PERMANENT': False,
        'SESSION_USE_SIGNER': True,
        'SESSION_KEY_PREFIX': 'banking:',
        'SESSION_COOKIE_SECURE': config.get('ENVIRONMENT') == 'production',
        'SESSION_COOKIE_HTTPONLY': True,
        'SESSION_COOKIE_SAMESITE': 'Lax',
        'WTF_CSRF_TIME_LIMIT': 3600,  # 1 hour CSRF token validity
        'PERMANENT_SESSION_LIFETIME': timedelta(minutes=30),
    })
    
    # Initialize extensions
    Session(app)
    CSRFProtect(app)
    
    # Enable CORS with security headers
    CORS(app, origins=['https://yourdomain.com'], supports_credentials=True)
    
    # Security headers with Flask-Talisman
    Talisman(app, 
        force_https=config.get('ENVIRONMENT') == 'production',
        strict_transport_security=True,
        content_security_policy={
            'default-src': "'self'",
            'script-src': "'self' 'unsafe-inline'",
            'style-src': "'self' 'unsafe-inline'",
            'img-src': "'self' data: https:",
            'connect-src': "'self'",
            'font-src': "'self'",
            'object-src': "'none'",
            'media-src': "'self'",
            'frame-ancestors': "'none'",
        }
    )
    
    # Rate limiting
    limiter = Limiter(
        app,
        key_func=get_remote_address,
        default_limits=[f"{config.get('MAX_REQUESTS_PER_MINUTE')} per minute"]
    )
    
    return app, limiter

app, limiter = create_secure_banking_app()

# ============= AUTHENTICATION AND AUTHORIZATION =============
class AuthenticationManager:
    """Secure authentication manager for banking application"""
    
    def __init__(self, session_manager: SecureSessionManager, security_manager: SecurityManager):
        self.session_manager = session_manager
        self.security_manager = security_manager
    
    def authenticate_user(self, username: str, password: str) -> Optional[Dict]:
        """Authenticate user with secure password verification"""
        # In production, this would query a secure database
        # For demo purposes, using a simple user store
        users_db = {
            'demo_user': {
                'user_id': 'user_123',
                'password_hash': self.security_manager.hash_password('secure_password_123'),
                'role': 'customer',
                'account_numbers': ['1234567890', '0987654321']
            }
        }
        
        user = users_db.get(username)
        if not user:
            logger.warning(f"Authentication failed - user not found: {username}")
            return None
        
        if not self.security_manager.verify_password(password, user['password_hash']):
            logger.warning(f"Authentication failed - invalid password: {username}")
            return None
        
        return {
            'user_id': user['user_id'],
            'username': username,
            'role': user['role'],
            'account_numbers': user['account_numbers']
        }
    
    def require_auth(self, f):
        """Decorator to require authentication for endpoints"""
        @wraps(f)
        def decorated_function(*args, **kwargs):
            session_id = request.headers.get('X-Session-Token') or session.get('session_id')
            
            if not session_id:
                return jsonify({'error': 'Authentication required'}), 401
            
            session_data = self.session_manager.get_session(session_id)
            if not session_data:
                return jsonify({'error': 'Invalid or expired session'}), 401
            
            g.current_user = session_data['user_data']
            g.session_id = session_id
            
            return f(*args, **kwargs)
        return decorated_function

# Initialize authentication manager
auth_manager = AuthenticationManager(session_manager, security_manager)

# ============= SECURE API ENDPOINTS =============
@app.errorhandler(429)
def ratelimit_handler(e):
    """Rate limit exceeded handler"""
    return jsonify({'error': 'Rate limit exceeded. Please try again later.'}), 429

@app.errorhandler(400)
def bad_request(e):
    """Bad request handler"""
    return jsonify({'error': 'Invalid request format'}), 400

@app.errorhandler(500)
def internal_error(e):
    """Internal error handler - don't leak sensitive information"""
    logger.error(f"Internal server error: {str(e)}")
    return jsonify({'error': 'Internal server error'}), 500

@app.route('/health', methods=['GET'])
@limiter.limit("10 per minute")
def health_check():
    """Secure health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '2.0.0'
    })

@app.route('/auth/login', methods=['POST'])
@limiter.limit("5 per minute")
def login():
    """Secure login endpoint"""
    try:
        data = request.get_json(force=True)
        
        if not data or 'username' not in data or 'password' not in data:
            return jsonify({'error': 'Username and password required'}), 400
        
        username = data['username'].strip()
        password = data['password']
        
        # Validate input
        sanitized_username, pii_found, is_malicious = input_validator.sanitize_input(username)
        if is_malicious:
            return jsonify({'error': 'Invalid input detected'}), 400
        
        # Authenticate user
        user_data = auth_manager.authenticate_user(sanitized_username, password)
        if not user_data:
            return jsonify({'error': 'Invalid credentials'}), 401
        
        # Create secure session
        session_id = session_manager.create_session(user_data['user_id'], user_data)
        
        return jsonify({
            'message': 'Login successful',
            'session_id': session_id,
            'expires_in': config.get('SESSION_TIMEOUT')
        }), 200
        
    except Exception as e:
        logger.error(f"Login error: {str(e)}")
        return jsonify({'error': 'Authentication failed'}), 500

@app.route('/auth/logout', methods=['POST'])
@limiter.limit("10 per minute")
def logout():
    """Secure logout endpoint"""
    session_id = request.headers.get('X-Session-Token') or session.get('session_id')
    
    if session_id:
        session_manager.invalidate_session(session_id)
        session.clear()
    
    return jsonify({'message': 'Logout successful'}), 200

@app.route('/account/balance', methods=['GET'])
@limiter.limit("30 per minute")
@auth_manager.require_auth
def get_account_balance():
    """Secure account balance endpoint"""
    try:
        user = g.current_user
        account_number = request.args.get('account_number')
        
        if not account_number:
            return jsonify({'error': 'Account number required'}), 400
        
        # Validate account ownership
        if account_number not in user.get('account_numbers', []):
            logger.warning(f"Unauthorized account access attempt: {user['user_id']} -> {account_number}")
            return jsonify({'error': 'Unauthorized account access'}), 403
        
        # In production, this would query secure banking database
        mock_balance = {
            '1234567890': 15250.75,
            '0987654321': 8930.50
        }
        
        balance = mock_balance.get(account_number, 0.0)
        
        return jsonify({
            'account_number': account_number[-4:].rjust(len(account_number), '*'),  # Mask account number
            'balance': balance,
            'currency': 'USD',
            'timestamp': datetime.utcnow().isoformat()
        }), 200
        
    except Exception as e:
        logger.error(f"Balance inquiry error: {str(e)}")
        return jsonify({'error': 'Unable to retrieve balance'}), 500

@app.route('/chat', methods=['POST'])
@limiter.limit("20 per minute")
@auth_manager.require_auth
def secure_chat():
    """Secure chat endpoint with comprehensive validation"""
    try:
        payload = request.get_json(force=True)
        user_message = payload.get('message', '').strip()
        
        if not user_message:
            return jsonify({'error': 'Message cannot be empty'}), 400
        
        # Advanced input validation and sanitization
        sanitized_message, pii_found, is_malicious = input_validator.sanitize_input(user_message)
        
        if is_malicious:
            logger.warning(f"Malicious input blocked from user {g.current_user['user_id']}")
            return jsonify({'error': 'Invalid input detected'}), 400
        
        if not sanitized_message:
            return jsonify({'error': 'Message contains only invalid content'}), 400
        
        # Detect intent securely
        intent = detect_intent_secure(sanitized_message)
        
        # Log the interaction (without sensitive data)
        logger.info(f"Chat interaction - User: {g.current_user['user_id']}, Intent: {intent}")
        
        # Handle different intents
        if intent in ['balance', 'transaction']:
            return handle_banking_operation(intent, sanitized_message)
        else:
            return handle_faq_query(sanitized_message)
        
    except Exception as e:
        logger.error(f"Chat endpoint error: {str(e)}")
        return jsonify({'error': 'Unable to process request'}), 500

def detect_intent_secure(message: str) -> str:
    """Secure intent detection"""
    message_lower = message.lower()
    
    if any(keyword in message_lower for keyword in ['balance', 'account balance', 'check balance']):
        return 'balance'
    elif any(keyword in message_lower for keyword in ['transfer', 'transaction', 'send money', 'payment']):
        return 'transaction'
    else:
        return 'faq'

def handle_banking_operation(intent: str, message: str) -> tuple:
    """Handle banking operations securely"""
    user = g.current_user
    
    if intent == 'balance':
        # Provide secure balance inquiry guidance
        return jsonify({
            'type': 'banking_operation',
            'intent': intent,
            'message': 'I can help you check your account balance. Please use the /account/balance endpoint with your account number.',
            'available_accounts': [acc[-4:].rjust(len(acc), '*') for acc in user.get('account_numbers', [])]
        }), 200
    
    elif intent == 'transaction':
        return jsonify({
            'type': 'banking_operation',
            'intent': intent,
            'message': 'For security reasons, transactions require additional verification. Please use the secure transaction endpoints.',
            'next_steps': ['Verify identity', 'Provide transaction details', 'Confirm with OTP']
        }), 200
    
    return jsonify({'error': 'Operation not supported'}), 400

def handle_faq_query(message: str) -> tuple:
    """Handle FAQ queries with RAG (simplified for demo)"""
    # In production, this would use the secure RAG implementation
    response = "I'm here to help with your banking questions. For account-specific inquiries, please log in and use the secure banking endpoints."
    
    return jsonify({
        'type': 'faq',
        'message': response,
        'timestamp': datetime.utcnow().isoformat()
    }), 200

# ============= APPLICATION STARTUP =============
if __name__ == '__main__':
    if config.get('ENVIRONMENT') == 'production':
        # Production configuration
        logger.info("Starting banking application in PRODUCTION mode")
        app.run(
            host='0.0.0.0',
            port=int(os.environ.get('PORT', 5000)),
            debug=False,
            ssl_context='adhoc'  # Use proper SSL certificates in production
        )
    else:
        # Development configuration
        logger.info("Starting banking application in DEVELOPMENT mode")
        app.run(
            host='127.0.0.1',
            port=5000,
            debug=True,
            ssl_context='adhoc'
        )
'''

# Save the main Flask application
with open('improved_banking_app_main.py', 'w', encoding='utf-8') as f:
    f.write(improved_flask_main)

print("✅ Improved main Flask banking application created!")
print("📄 Saved as: improved_banking_app_main.py")

# Create environment variables template
env_template = '''# ENVIRONMENT VARIABLES TEMPLATE FOR SECURE BANKING APPLICATION
# Copy this file to .env and fill in your actual values
# NEVER commit the actual .env file to version control

# Core Security Keys (Generate new ones for production)
SECRET_KEY=your_very_long_secret_key_at_least_32_characters_long_for_production
JWT_SECRET_KEY=another_very_long_secret_key_for_jwt_tokens_in_production
GEMINI_API_KEY=your_actual_gemini_api_key_here

# Database Configuration
REDIS_URL=redis://localhost:6379/0

# Application Configuration
ENVIRONMENT=development
LOG_LEVEL=INFO
SESSION_TIMEOUT=1800
MAX_REQUESTS_PER_MINUTE=60

# Optional Configuration
CHUNK_SIZE=800
CHUNK_OVERLAP=200
TOP_K=5
QDRANT_URL=
QDRANT_COLLECTION=bank_kb
RETAIL_PDF=retail_faq.pdf

# Production specific
# ENVIRONMENT=production
# Uncomment and configure for production deployment
'''

with open('.env.template', 'w', encoding='utf-8') as f:
    f.write(env_template)

print("✅ Environment variables template created!")
print("📄 Saved as: .env.template")