
"""
BANKING APPLICATION WITH DEEP LEARNING INTENT RECOGNITION
=========================================================
Complete Flask banking application using neural networks for intent detection
and Gemini Flash 2.0 for response generation with FAQ document integration.
"""

from deep_learning_intent_system import *
import fitz  # PyMuPDF for PDF processing

# ============= CONFIGURATION =============
class BankingAppConfig:
    """Configuration for banking application"""

    def __init__(self):
        # Required environment variables
        self.GEMINI_API_KEY = os.environ.get('GEMINI_API_KEY')
        if not self.GEMINI_API_KEY:
            raise ValueError("GEMINI_API_KEY environment variable required")

        self.SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key-change-in-production')

        # Application settings
        self.PDF_PATH = os.environ.get('BANKING_FAQ_PDF', 'banking_faq.pdf')
        self.MODEL_PATH = 'intent_model.h5'
        self.TOKENIZER_PATH = 'tokenizer.pkl'
        self.ENCODER_PATH = 'label_encoder.pkl'
        self.MAX_REQUESTS_PER_MINUTE = int(os.environ.get('MAX_REQUESTS_PER_MINUTE', '60'))

config = BankingAppConfig()

# ============= GEMINI API CLIENT =============
class GeminiAPIClient:
    """Simplified Gemini API client for response generation"""

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash"

    def generate_response(self, user_message: str, intent_analysis: Dict, context: str = "") -> str:
        """Generate response using Gemini Flash 2.0"""

        prompt = f"""You are Annie, a professional banking assistant.

User Message: "{user_message}"
Intent Analysis: {json.dumps(intent_analysis, indent=2)}
FAQ Context: {context[:2000]}  # Limit context size

Based on the intent analysis, provide an appropriate response:

If the intent is FAQ_INQUIRY:
- Use the FAQ context to provide detailed, accurate information
- Be educational and helpful
- End with "Is there anything else I can help you with?"

If the intent is an ACTION (ACCOUNT_BALANCE_CHECK, FUND_TRANSFER, STOP_CHEQUE, ORDER_CHEQUE_BOOK):
- Acknowledge the request professionally  
- Explain the security requirements and next steps
- Be concise but thorough
- Mention any applicable fees or timeframes

Keep responses professional, clear, and appropriate for banking customers.
"""

        try:
            payload = {
                "contents": [{"role": "user", "parts": [{"text": prompt}]}],
                "generationConfig": {
                    "temperature": 0.3,
                    "topK": 20, 
                    "topP": 0.8,
                    "maxOutputTokens": 800
                }
            }

            response = requests.post(
                f"{self.base_url}:generateContent",
                json=payload,
                params={'key': self.api_key},
                timeout=30,
                verify=True
            )

            response.raise_for_status()
            result = response.json()
            return result["candidates"][0]["content"]["parts"][0]["text"]

        except Exception as e:
            logging.error(f"Gemini API error: {str(e)}")
            return "I apologize, but I'm having trouble generating a response right now. Please try again or contact customer support."

# ============= FAQ DOCUMENT PROCESSOR =============
class FAQDocumentProcessor:
    """Process FAQ PDF and provide context for responses"""

    def __init__(self, pdf_path: str):
        self.pdf_path = pdf_path
        self.faq_content = ""
        self.faq_sections = {}
        self.load_pdf()

    def load_pdf(self):
        """Load and process FAQ PDF"""
        if not os.path.exists(self.pdf_path):
            logging.warning(f"FAQ PDF not found: {self.pdf_path}")
            return

        try:
            doc = fitz.open(self.pdf_path)
            full_text = ""

            for page in doc:
                full_text += page.get_text("text")

            doc.close()
            self.faq_content = full_text
            self.parse_faq_sections()

            logging.info(f"Loaded FAQ document with {len(self.faq_content)} characters")

        except Exception as e:
            logging.error(f"Error loading FAQ PDF: {str(e)}")

    def parse_faq_sections(self):
        """Parse FAQ content into sections for better retrieval"""
        if not self.faq_content:
            return

        # Simple section parsing based on common FAQ patterns
        sections = self.faq_content.split('\n\n')

        for i, section in enumerate(sections):
            if len(section.strip()) > 20:  # Skip very short sections
                # Try to identify the topic
                lines = section.strip().split('\n')
                topic = lines[0][:100] if lines else f"Section_{i}"
                self.faq_sections[topic] = section.strip()

    def search_relevant_content(self, query: str, max_sections: int = 3) -> str:
        """Search for relevant FAQ content based on query"""
        if not self.faq_sections:
            return self.faq_content[:1000]  # Return first 1000 chars as fallback

        query_words = set(query.lower().split())
        scored_sections = []

        for topic, content in self.faq_sections.items():
            content_words = set(content.lower().split())
            # Simple word overlap scoring
            overlap = len(query_words.intersection(content_words))
            if overlap > 0:
                scored_sections.append((overlap, topic, content))

        # Sort by relevance and return top sections
        scored_sections.sort(key=lambda x: x[0], reverse=True)

        relevant_content = ""
        for score, topic, content in scored_sections[:max_sections]:
            relevant_content += content + "\n\n"

        return relevant_content[:2000]  # Limit content size

# ============= FLASK APPLICATION =============
app = Flask(__name__)
app.config['SECRET_KEY'] = config.SECRET_KEY

# Security and rate limiting
CORS(app, origins=['http://localhost:3000'])
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=[f"{config.MAX_REQUESTS_PER_MINUTE} per minute"]
)

# Initialize components
gemini_client = GeminiAPIClient(config.GEMINI_API_KEY)
faq_processor = FAQDocumentProcessor(config.PDF_PATH)
intent_classifier = None
intent_analyzer = None

# Session storage (use Redis in production)
SESSIONS = {}

# ============= UTILITY FUNCTIONS =============
def initialize_intent_model():
    """Initialize or train the intent classification model"""
    global intent_classifier, intent_analyzer

    intent_classifier = DeepLearningIntentClassifier()

    # Try to load existing model
    try:
        if (os.path.exists(config.MODEL_PATH) and 
            os.path.exists(config.TOKENIZER_PATH) and 
            os.path.exists(config.ENCODER_PATH)):

            intent_classifier.load_model(
                config.MODEL_PATH,
                config.TOKENIZER_PATH, 
                config.ENCODER_PATH
            )
            logging.info("Loaded existing intent model")
        else:
            # Train new model
            logging.info("Training new intent model...")
            data_provider = BankingIntentData()
            texts, labels = data_provider.get_training_data()

            intent_classifier.train(texts, labels, epochs=30)
            intent_classifier.save_model(
                config.MODEL_PATH,
                config.TOKENIZER_PATH,
                config.ENCODER_PATH
            )
            logging.info("New intent model trained and saved")

    except Exception as e:
        logging.error(f"Error initializing intent model: {str(e)}")
        raise

    # Initialize enhanced analyzer
    intent_analyzer = EnhancedIntentAnalyzer(intent_classifier)

def create_session(user_data: Dict = None) -> str:
    """Create a new session"""
    session_id = str(uuid.uuid4())[:16]
    SESSIONS[session_id] = {
        'created_at': datetime.utcnow(),
        'last_activity': datetime.utcnow(),
        'conversation_history': [],
        'user_data': user_data or {}
    }
    return session_id

def get_session(session_id: str) -> Optional[Dict]:
    """Get session data"""
    if session_id not in SESSIONS:
        return None

    session = SESSIONS[session_id]

    # Check session timeout (30 minutes)
    if datetime.utcnow() - session['last_activity'] > timedelta(minutes=30):
        del SESSIONS[session_id]
        return None

    session['last_activity'] = datetime.utcnow()
    return session

def sanitize_input(text: str) -> Tuple[str, bool]:
    """Basic input sanitization"""
    if not text or not isinstance(text, str):
        return "", True

    # Check for malicious patterns
    malicious_patterns = [
        r'<script[^>]*>.*</script>',
        r'javascript:',
        r'(union|select|drop|insert|delete)\s+',
        r'ignore\s+previous\s+instructions'
    ]

    for pattern in malicious_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return "", True

    # Basic cleanup
    cleaned = re.sub(r'[<>"\'&]', '', text).strip()
    return cleaned, False

# ============= FLASK ROUTES =============
@app.route('/health', methods=['GET'])
@limiter.limit("10 per minute")
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'model_loaded': intent_classifier is not None and intent_classifier.is_trained,
        'faq_loaded': len(faq_processor.faq_content) > 0
    })

@app.route('/chat', methods=['POST'])
@limiter.limit("30 per minute")
def chat():
    """Main chat endpoint with deep learning intent recognition"""
    try:
        # Get request data
        payload = request.get_json(force=True)
        user_message = payload.get('message', '').strip()
        session_id = payload.get('session_id')

        if not user_message:
            return jsonify({'error': 'Message cannot be empty'}), 400

        # Sanitize input
        sanitized_message, is_malicious = sanitize_input(user_message)
        if is_malicious or not sanitized_message:
            return jsonify({'error': 'Invalid input detected'}), 400

        # Get or create session
        if session_id:
            session_data = get_session(session_id)
        else:
            session_data = None

        if not session_data:
            session_id = create_session()
            session_data = SESSIONS[session_id]

        # Perform intent analysis using deep learning
        intent_analysis = intent_analyzer.analyze_intent(sanitized_message)

        # Log interaction
        logging.info(f"Intent: {intent_analysis['intent']}, Confidence: {intent_analysis['confidence']:.2f}, Action: {intent_analysis['is_action_request']}")

        # Get relevant FAQ context
        context = ""
        if intent_analysis['intent'] == 'FAQ_INQUIRY':
            context = faq_processor.search_relevant_content(sanitized_message)

        # Generate response using Gemini
        response_text = gemini_client.generate_response(
            sanitized_message, 
            intent_analysis,
            context
        )

        # Update conversation history
        session_data['conversation_history'].append({
            'user_message': sanitized_message,
            'intent_analysis': intent_analysis,
            'bot_response': response_text,
            'timestamp': datetime.utcnow().isoformat()
        })

        # Prepare response
        response = {
            'answer': response_text,
            'intent_analysis': {
                'intent': intent_analysis['intent'],
                'confidence': intent_analysis['confidence'],
                'is_action_request': intent_analysis['is_action_request'],
                'extracted_entities': intent_analysis['extracted_entities'],
                'reasoning': intent_analysis['reasoning']
            },
            'session_id': session_id,
            'timestamp': datetime.utcnow().isoformat()
        }

        return jsonify(response), 200

    except Exception as e:
        logging.error(f"Chat endpoint error: {str(e)}")
        return jsonify({
            'error': 'Unable to process your request',
            'session_id': session_id if 'session_id' in locals() else None
        }), 500

@app.route('/intent-demo', methods=['POST'])
@limiter.limit("20 per minute") 
def intent_demo():
    """Demo endpoint to show intent classification results"""
    try:
        payload = request.get_json(force=True)
        text = payload.get('text', '').strip()

        if not text:
            return jsonify({'error': 'Text cannot be empty'}), 400

        # Sanitize
        sanitized_text, is_malicious = sanitize_input(text)
        if is_malicious:
            return jsonify({'error': 'Invalid input'}), 400

        # Analyze intent
        analysis = intent_analyzer.analyze_intent(sanitized_text)

        return jsonify({
            'input_text': sanitized_text,
            'analysis': analysis,
            'timestamp': datetime.utcnow().isoformat()
        }), 200

    except Exception as e:
        logging.error(f"Intent demo error: {str(e)}")
        return jsonify({'error': 'Analysis failed'}), 500

# ============= APPLICATION STARTUP =============
if __name__ == '__main__':
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('banking_app_dl.log'),
            logging.StreamHandler()
        ]
    )

    # Initialize intent model
    logging.info("Initializing deep learning intent model...")
    initialize_intent_model()

    # Start application
    logging.info("Starting Banking Application with Deep Learning Intent Recognition")
    app.run(host='127.0.0.1', port=5000, debug=True)
