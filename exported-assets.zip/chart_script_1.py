import plotly.graph_objects as go
import plotly.io as pio

# Data
metrics = ["Security", "Intent Acc", "Prod Ready", "Scalability", "Code Quality", "Test Coverage", "Documentation", "Compliance"]
original_scores = [0, 30, 10, 15, 25, 0, 5, 5]
improved_scores = [89, 92, 95, 88, 90, 85, 95, 92]

# Create radar chart
fig = go.Figure()

# Add original application trace
fig.add_trace(go.Scatterpolar(
    r=original_scores,
    theta=metrics,
    fill='toself',
    name='Original',
    line=dict(color='#DB4545', width=3),
    fillcolor='rgba(219, 69, 69, 0.3)',
    marker=dict(size=8, color='#DB4545')
))

# Add improved application trace
fig.add_trace(go.Scatterpolar(
    r=improved_scores,
    theta=metrics,
    fill='toself',
    name='Improved',
    line=dict(color='#2E8B57', width=3),
    fillcolor='rgba(46, 139, 87, 0.3)',
    marker=dict(size=8, color='#2E8B57')
))

# Update layout
fig.update_layout(
    polar=dict(
        radialaxis=dict(
            visible=True,
            range=[0, 100],
            tickmode='linear',
            tick0=0,
            dtick=20,
            showticklabels=True,
            ticks='outside'
        ),
        angularaxis=dict(
            tickfont=dict(size=12)
        )
    ),
    title='Banking App Transformation',
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.05,
        xanchor='center',
        x=0.5
    ),
    showlegend=True
)

# Save the chart
fig.write_image("banking_transformation_radar.png")