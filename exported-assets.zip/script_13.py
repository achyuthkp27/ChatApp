# Create the second part of the advanced chatbot framework with Flask integration
advanced_chatbot_part2 = '''
"""
ADVANCED CHATBOT FRAMEWORK - PART 2: FLASK INTEGRATION
======================================================
Flask application with advanced features, security, API integration,
testing framework, and production deployment capabilities.
"""

from advanced_chatbot_framework_part1 import *
import threading
import queue
from functools import wraps
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_bcrypt import Bcrypt
import redis
from celery import Celery

# ============= SECURITY AND AUTHENTICATION =============
class SecurityManager:
    """Comprehensive security management"""
    
    def __init__(self, app: Flask):
        self.app = app
        self.bcrypt = Bcrypt(app)
        self.jwt = JWTManager(app)
        self.redis_client = redis.Redis(host='localhost', port=6379, db=0)
        
        # Configure JWT
        app.config['JWT_SECRET_KEY'] = config.SECRET_KEY
        app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
        
        self.setup_security_headers()
        self.setup_rate_limiting()
    
    def setup_security_headers(self):
        """Setup security headers"""
        @self.app.after_request
        def set_security_headers(response):
            response.headers['X-Content-Type-Options'] = 'nosniff'
            response.headers['X-Frame-Options'] = 'DENY'
            response.headers['X-XSS-Protection'] = '1; mode=block'
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
            response.headers['Content-Security-Policy'] = "default-src 'self'"
            return response
    
    def setup_rate_limiting(self):
        """Setup advanced rate limiting"""
        # This would integrate with Redis for distributed rate limiting
        pass
    
    def hash_password(self, password: str) -> str:
        """Hash password securely"""
        return self.bcrypt.generate_password_hash(password).decode('utf-8')
    
    def verify_password(self, password: str, hashed: str) -> bool:
        """Verify password"""
        return self.bcrypt.check_password_hash(hashed, password)
    
    def create_user_token(self, user_id: str) -> str:
        """Create JWT token for user"""
        return create_access_token(identity=user_id)
    
    def require_auth(self, f):
        """Authentication required decorator"""
        @wraps(f)
        @jwt_required()
        def decorated_function(*args, **kwargs):
            current_user = get_jwt_identity()
            g.current_user_id = current_user
            return f(*args, **kwargs)
        return decorated_function
    
    def validate_input(self, data: str) -> Tuple[bool, str]:
        """Comprehensive input validation"""
        if not data or not isinstance(data, str):
            return False, "Invalid input type"
        
        # Check for malicious patterns
        malicious_patterns = [
            r'<script[^>]*>.*?</script>',
            r'javascript:',
            r'vbscript:',
            r'onload=',
            r'onerror=',
            r'(union|select|drop|insert|delete|update)\\s+',
            r'--\\s*$',
            r';\\s*--',
        ]
        
        for pattern in malicious_patterns:
            if re.search(pattern, data, re.IGNORECASE):
                return False, "Potentially malicious content detected"
        
        # Length validation
        if len(data) > 5000:
            return False, "Input too long"
        
        return True, "Valid"
    
    def sanitize_input(self, data: str) -> str:
        """Sanitize user input"""
        # Remove potentially dangerous characters
        sanitized = re.sub(r'[<>&"\\']', '', data)
        return sanitized.strip()

# ============= API INTEGRATION MANAGER =============
class APIIntegrationManager:
    """Manage external API integrations"""
    
    def __init__(self, config: ChatbotConfig):
        self.config = config
        self.api_cache = {}
        self.api_connectors = {}
        self.setup_connectors()
    
    def setup_connectors(self):
        """Setup API connectors"""
        # OpenAI connector
        if self.config.OPENAI_API_KEY:
            self.api_connectors['openai'] = {
                'base_url': 'https://api.openai.com/v1',
                'headers': {
                    'Authorization': f'Bearer {self.config.OPENAI_API_KEY}',
                    'Content-Type': 'application/json'
                }
            }
        
        # Gemini connector
        if self.config.GEMINI_API_KEY:
            self.api_connectors['gemini'] = {
                'base_url': 'https://generativelanguage.googleapis.com/v1beta/models',
                'headers': {
                    'Content-Type': 'application/json'
                },
                'params': {
                    'key': self.config.GEMINI_API_KEY
                }
            }
    
    def make_secure_api_call(self, service: str, endpoint: str, data: Dict) -> Optional[Dict]:
        """Make secure API call with error handling and caching"""
        
        # Check cache first
        cache_key = f"{service}:{endpoint}:{hashlib.md5(json.dumps(data, sort_keys=True).encode()).hexdigest()}"
        
        if cache_key in self.api_cache:
            cache_entry = self.api_cache[cache_key]
            if datetime.utcnow() - cache_entry['timestamp'] < timedelta(seconds=config.CACHE_TTL):
                return cache_entry['data']
        
        # Make API call
        connector = self.api_connectors.get(service)
        if not connector:
            logging.error(f"API connector not found: {service}")
            return None
        
        try:
            url = f"{connector['base_url']}/{endpoint}"
            
            response = requests.post(
                url,
                json=data,
                headers=connector['headers'],
                params=connector.get('params', {}),
                timeout=30,
                verify=True
            )
            
            response.raise_for_status()
            result = response.json()
            
            # Cache the result
            self.api_cache[cache_key] = {
                'data': result,
                'timestamp': datetime.utcnow()
            }
            
            return result
            
        except requests.exceptions.RequestException as e:
            logging.error(f"API call failed for {service}: {str(e)}")
            return None
    
    def generate_response_with_llm(self, prompt: str, service: str = 'gemini') -> str:
        """Generate response using LLM service"""
        
        if service == 'openai':
            data = {
                'model': 'gpt-3.5-turbo',
                'messages': [{'role': 'user', 'content': prompt}],
                'max_tokens': 500,
                'temperature': 0.7
            }
            result = self.make_secure_api_call('openai', 'chat/completions', data)
            
            if result and 'choices' in result:
                return result['choices'][0]['message']['content']
        
        elif service == 'gemini':
            data = {
                'contents': [{'parts': [{'text': prompt}]}],
                'generationConfig': {
                    'temperature': 0.7,
                    'topK': 20,
                    'topP': 0.8,
                    'maxOutputTokens': 500
                }
            }
            result = self.make_secure_api_call('gemini', 'gemini-2.0-flash:generateContent', data)
            
            if result and 'candidates' in result:
                return result['candidates'][0]['content']['parts'][0]['text']
        
        return "I apologize, but I'm having trouble generating a response right now."

# ============= KNOWLEDGE GRAPH MANAGER =============
class KnowledgeGraphManager:
    """Manage knowledge graphs for semantic understanding"""
    
    def __init__(self, db_connection):
        self.db = db_connection
        self.initialize_knowledge_base()
    
    def initialize_knowledge_base(self):
        """Initialize knowledge graph tables"""
        cursor = self.db.cursor()
        
        # Entities table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS kb_entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_name TEXT UNIQUE,
                entity_type TEXT,
                properties TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Relations table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS kb_relations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject_entity INTEGER,
                relation_type TEXT,
                object_entity INTEGER,
                confidence_score REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (subject_entity) REFERENCES kb_entities (id),
                FOREIGN KEY (object_entity) REFERENCES kb_entities (id)
            )
        ''')
        
        # Semantic embeddings table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS kb_embeddings (
                entity_id INTEGER PRIMARY KEY,
                embedding_vector BLOB,
                model_version TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (entity_id) REFERENCES kb_entities (id)
            )
        ''')
        
        self.db.commit()
    
    def add_entity(self, name: str, entity_type: str, properties: Dict = None) -> int:
        """Add entity to knowledge graph"""
        cursor = self.db.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO kb_entities (entity_name, entity_type, properties) VALUES (?, ?, ?)",
            (name, entity_type, json.dumps(properties or {}))
        )
        self.db.commit()
        return cursor.lastrowid
    
    def add_relation(self, subject_name: str, relation_type: str, object_name: str, confidence: float = 1.0):
        """Add relation between entities"""
        cursor = self.db.cursor()
        
        # Get entity IDs
        cursor.execute("SELECT id FROM kb_entities WHERE entity_name = ?", (subject_name,))
        subject_id = cursor.fetchone()
        
        cursor.execute("SELECT id FROM kb_entities WHERE entity_name = ?", (object_name,))
        object_id = cursor.fetchone()
        
        if subject_id and object_id:
            cursor.execute(
                "INSERT INTO kb_relations (subject_entity, relation_type, object_entity, confidence_score) VALUES (?, ?, ?, ?)",
                (subject_id[0], relation_type, object_id[0], confidence)
            )
            self.db.commit()
    
    def find_related_entities(self, entity_name: str, max_depth: int = 2) -> List[Dict]:
        """Find entities related to given entity"""
        cursor = self.db.cursor()
        
        query = '''
            WITH RECURSIVE related_entities(id, name, type, relation, depth) AS (
                SELECT e.id, e.entity_name, e.entity_type, 'root', 0
                FROM kb_entities e
                WHERE e.entity_name = ?
                
                UNION ALL
                
                SELECT e.id, e.entity_name, e.entity_type, r.relation_type, re.depth + 1
                FROM related_entities re
                JOIN kb_relations r ON (re.id = r.subject_entity OR re.id = r.object_entity)
                JOIN kb_entities e ON (
                    (r.subject_entity = e.id AND r.object_entity = re.id) OR
                    (r.object_entity = e.id AND r.subject_entity = re.id)
                )
                WHERE re.depth < ? AND e.id != re.id
            )
            SELECT DISTINCT name, type, relation, depth
            FROM related_entities
            WHERE depth > 0
        '''
        
        cursor.execute(query, (entity_name, max_depth))
        results = cursor.fetchall()
        
        return [
            {
                'name': row[0],
                'type': row[1],
                'relation': row[2],
                'depth': row[3]
            }
            for row in results
        ]

# ============= TESTING AND OPTIMIZATION FRAMEWORK =============
class ChatbotTestFramework:
    """Comprehensive testing framework for chatbot"""
    
    def __init__(self, nlu_engine: AdvancedNLUEngine, app: Flask):
        self.nlu_engine = nlu_engine
        self.app = app
        self.test_results = []
    
    def create_test_suite(self) -> List[Dict]:
        """Create comprehensive test suite"""
        test_cases = [
            # Intent recognition tests
            {
                'type': 'intent_test',
                'input': 'What is my account balance?',
                'expected_intent': 'account_balance_check',
                'min_confidence': 0.8
            },
            {
                'type': 'intent_test',
                'input': 'Transfer $500 to John',
                'expected_intent': 'money_transfer',
                'min_confidence': 0.8
            },
            
            # Entity extraction tests
            {
                'type': 'entity_test',
                'input': 'Transfer $500 to account 123456789',
                'expected_entities': [
                    {'type': 'amount', 'value': '500'},
                    {'type': 'account_number', 'value': '123456789'}
                ]
            },
            
            # Conversation flow tests
            {
                'type': 'conversation_test',
                'conversation': [
                    {'user': 'I want to transfer money', 'expected_state': 'collecting_transfer_info'},
                    {'user': '$100', 'expected_state': 'confirming_transfer'},
                    {'user': 'yes', 'expected_state': 'processing_transfer'}
                ]
            },
            
            # Security tests
            {
                'type': 'security_test',
                'input': '<script>alert("xss")</script>',
                'should_be_blocked': True
            },
            {
                'type': 'security_test',
                'input': 'SELECT * FROM users',
                'should_be_blocked': True
            },
            
            # Performance tests
            {
                'type': 'performance_test',
                'concurrent_requests': 10,
                'max_response_time': 2.0  # seconds
            }
        ]
        
        return test_cases
    
    def run_intent_test(self, test_case: Dict) -> Dict:
        """Run intent recognition test"""
        intent, sentiment, emotion = self.nlu_engine.predict_intent_and_entities(test_case['input'])
        
        result = {
            'test_type': 'intent_test',
            'input': test_case['input'],
            'expected_intent': test_case['expected_intent'],
            'actual_intent': intent.name,
            'confidence': intent.confidence,
            'passed': (
                intent.name == test_case['expected_intent'] and
                intent.confidence >= test_case['min_confidence']
            )
        }
        
        return result
    
    def run_security_test(self, test_case: Dict) -> Dict:
        """Run security test"""
        security_manager = SecurityManager(self.app)
        is_valid, message = security_manager.validate_input(test_case['input'])
        
        result = {
            'test_type': 'security_test',
            'input': test_case['input'],
            'should_be_blocked': test_case['should_be_blocked'],
            'was_blocked': not is_valid,
            'message': message,
            'passed': (not is_valid) == test_case['should_be_blocked']
        }
        
        return result
    
    def run_performance_test(self, test_case: Dict) -> Dict:
        """Run performance test"""
        import time
        import threading
        
        results = []
        
        def make_request():
            start_time = time.time()
            with self.app.test_client() as client:
                response = client.post('/chat', json={'message': 'Hello'})
                end_time = time.time()
                results.append(end_time - start_time)
        
        # Create and start threads
        threads = []
        for _ in range(test_case['concurrent_requests']):
            thread = threading.Thread(target=make_request)
            threads.append(thread)
            thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        avg_response_time = np.mean(results)
        max_response_time = max(results)
        
        result = {
            'test_type': 'performance_test',
            'concurrent_requests': test_case['concurrent_requests'],
            'avg_response_time': avg_response_time,
            'max_response_time': max_response_time,
            'target_max_time': test_case['max_response_time'],
            'passed': max_response_time <= test_case['max_response_time']
        }
        
        return result
    
    def run_all_tests(self) -> Dict:
        """Run complete test suite"""
        test_cases = self.create_test_suite()
        results = []
        
        for test_case in test_cases:
            if test_case['type'] == 'intent_test':
                result = self.run_intent_test(test_case)
            elif test_case['type'] == 'security_test':
                result = self.run_security_test(test_case)
            elif test_case['type'] == 'performance_test':
                result = self.run_performance_test(test_case)
            else:
                continue
            
            results.append(result)
            self.test_results.append(result)
        
        # Calculate summary statistics
        total_tests = len(results)
        passed_tests = len([r for r in results if r['passed']])
        pass_rate = (passed_tests / total_tests) * 100 if total_tests > 0 else 0
        
        summary = {
            'total_tests': total_tests,
            'passed_tests': passed_tests,
            'failed_tests': total_tests - passed_tests,
            'pass_rate': pass_rate,
            'results': results,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        return summary

# ============= MONITORING AND ANALYTICS =============
class MonitoringManager:
    """Comprehensive monitoring and analytics"""
    
    def __init__(self, db_connection):
        self.db = db_connection
        self.metrics_cache = {}
        self.setup_monitoring_tables()
    
    def setup_monitoring_tables(self):
        """Setup monitoring database tables"""
        cursor = self.db.cursor()
        
        # Performance metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_name TEXT,
                metric_value REAL,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                metadata TEXT
            )
        ''')
        
        # Error logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS error_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                error_type TEXT,
                error_message TEXT,
                stack_trace TEXT,
                user_id TEXT,
                session_id TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Usage analytics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS usage_analytics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT,
                session_id TEXT,
                intent TEXT,
                response_time REAL,
                satisfaction_score INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        self.db.commit()
    
    def log_performance_metric(self, metric_name: str, value: float, metadata: Dict = None):
        """Log performance metric"""
        cursor = self.db.cursor()
        cursor.execute(
            "INSERT INTO performance_metrics (metric_name, metric_value, metadata) VALUES (?, ?, ?)",
            (metric_name, value, json.dumps(metadata or {}))
        )
        self.db.commit()
    
    def log_error(self, error_type: str, message: str, stack_trace: str = "", user_id: str = "", session_id: str = ""):
        """Log error"""
        cursor = self.db.cursor()
        cursor.execute(
            "INSERT INTO error_logs (error_type, error_message, stack_trace, user_id, session_id) VALUES (?, ?, ?, ?, ?)",
            (error_type, message, stack_trace, user_id, session_id)
        )
        self.db.commit()
    
    def log_usage(self, user_id: str, session_id: str, intent: str, response_time: float, satisfaction: int = None):
        """Log usage analytics"""
        cursor = self.db.cursor()
        cursor.execute(
            "INSERT INTO usage_analytics (user_id, session_id, intent, response_time, satisfaction_score) VALUES (?, ?, ?, ?, ?)",
            (user_id, session_id, intent, response_time, satisfaction)
        )
        self.db.commit()
    
    def get_analytics_dashboard_data(self) -> Dict:
        """Get data for analytics dashboard"""
        cursor = self.db.cursor()
        
        # Get usage statistics
        cursor.execute('''
            SELECT intent, COUNT(*) as count, AVG(response_time) as avg_response_time
            FROM usage_analytics
            WHERE timestamp >= datetime('now', '-7 days')
            GROUP BY intent
            ORDER BY count DESC
        ''')
        intent_stats = [{'intent': row[0], 'count': row[1], 'avg_response_time': row[2]} for row in cursor.fetchall()]
        
        # Get error statistics
        cursor.execute('''
            SELECT error_type, COUNT(*) as count
            FROM error_logs
            WHERE timestamp >= datetime('now', '-7 days')
            GROUP BY error_type
            ORDER BY count DESC
        ''')
        error_stats = [{'error_type': row[0], 'count': row[1]} for row in cursor.fetchall()]
        
        # Get performance trends
        cursor.execute('''
            SELECT DATE(timestamp) as date, AVG(metric_value) as avg_value
            FROM performance_metrics
            WHERE metric_name = 'response_time' AND timestamp >= datetime('now', '-30 days')
            GROUP BY DATE(timestamp)
            ORDER BY date
        ''')
        performance_trend = [{'date': row[0], 'avg_response_time': row[1]} for row in cursor.fetchall()]
        
        return {
            'intent_statistics': intent_stats,
            'error_statistics': error_stats,
            'performance_trend': performance_trend,
            'generated_at': datetime.utcnow().isoformat()
        }

print("✅ Advanced Chatbot Framework (Part 2) Created!")
print("Features implemented:")
print("- Security and authentication with JWT")
print("- API integration manager with caching")
print("- Knowledge graph for semantic understanding")
print("- Comprehensive testing framework")
print("- Monitoring and analytics system")
print("- Production-ready security measures")
'''

# Save the second part of the framework
with open('advanced_chatbot_framework_part2.py', 'w', encoding='utf-8') as f:
    f.write(advanced_chatbot_part2)

print("✅ Advanced Chatbot Framework (Part 2) created!")
print("📄 Saved as: advanced_chatbot_framework_part2.py")