import plotly.graph_objects as go
import json

# Data provided
data = {
    "categories": ["Authentication", "Input Validation", "Session Management", "Data Encryption", "API Security", "Error Handling", "Configuration Management", "Logging Security", "Rate Limiting", "HTTPS/Transport Security"],
    "original_scores": [10, 20, 15, 5, 25, 30, 10, 20, 0, 5],
    "improved_scores": [95, 90, 95, 90, 85, 80, 90, 85, 90, 95]
}

# Abbreviate category names to meet 15 character limit
abbreviated_categories = [
    "Auth",
    "Input Valid", 
    "Session Mgmt",
    "Data Encrypt",
    "API Security",
    "Error Handle",
    "Config Mgmt", 
    "Log Security",
    "Rate Limit",
    "HTTPS/TLS"
]

# Create horizontal bar chart
fig = go.Figure()

# Add Original Application bars (red)
fig.add_trace(go.Bar(
    y=abbreviated_categories,
    x=data["original_scores"],
    name="Original",
    orientation='h',
    marker_color='#DB4545',  # Bright red
    cliponaxis=False
))

# Add Improved Application bars (green) 
fig.add_trace(go.Bar(
    y=abbreviated_categories,
    x=data["improved_scores"],
    name="Improved",
    orientation='h',
    marker_color='#2E8B57',  # Sea green
    cliponaxis=False
))

# Update layout
fig.update_layout(
    title="Security Score Comparison",
    xaxis_title="Score (0-100)",
    yaxis_title="Categories",
    barmode='group',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Update axes
fig.update_xaxes(range=[0, 100])
fig.update_yaxes()

# Save the chart
fig.write_image("security_comparison.png")